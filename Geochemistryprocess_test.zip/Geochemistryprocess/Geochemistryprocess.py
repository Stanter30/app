# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Geochemistryprocess
                                 A QGIS plugin
 Geochemistryprocess
                              -------------------
        begin                : 2023-04-21
        git sha              : $Format:%H$
        copyright            : (C) 2023 by S. Tereshkin
        email                : stanter30@gmail.com
 ***************************************************************************/
"""
from .resources import *

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

import pip
import re
import wx
import win32gui
import win32con
from win32gui import GetWindowText, GetForegroundWindow
import win32com.client
import subprocess
import sys
import etc
import json
from array import *
import numpy as np
import random
import statistics

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.text import TextPath
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.figure import Figure
from time import sleep
import operator
import time
import os.path
import math
from osgeo import osr, gdal, ogr
from operator import itemgetter, attrgetter, methodcaller
from itertools import groupby
import processing
from qgis.analysis import *
from qgis.core import *
from qgis.core.additions.edit import edit
from qgis.gui import *
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtCore import QSettings, QTranslator, QVariant, QCoreApplication, Qt, QRectF
from qgis.PyQt.QtGui import *
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QApplication, QAction, QProgressBar, QMessageBox, QHBoxLayout, QVBoxLayout, QSizePolicy, QPushButton, QDialog, QGridLayout, QDialogButtonBox, QMainWindow, QWidget
from qgis.PyQt.QtXml import QDomDocument
from PyQt5 import QtGui, QtCore, QtWidgets
from PyQt5.QtCore import QThread, QMetaMethod, QObject, pyqtSignal
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QWidget, QPushButton, QApplication, QMainWindow, QMenuBar, QMenu, QAction, QVBoxLayout
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from qgis.gui import QgsLayerTreeView, QgsMapCanvas, QgsMapCanvasItem, QgsMessageBar, QgsVertexMarker, QgsRubberBand
# Import the code for the dialog
from .Geochemistryprocess_dialog import driftingDialog
from .Geochemistryprocess_dialog import statisticsDialog
from .Geochemistryprocess_dialog import layoutDialog


class Message:
    def msg(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Неправильный источник данных")
        mbox.setIcon(QMessageBox.Warning)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

    def info(self):
        mbox = QMessageBox()
        mbox.setWindowTitle("Информация")
        mbox.setIcon(QMessageBox.Information)
        mbox.setStandardButtons(QMessageBox.Ok)
        return(mbox)

mbox = Message().msg()
mboxi = Message().info() 

element_names = ['Ac','Ag','Al','Am','Ar','As','At','Au','Ba','Be','Bh','Bi','Bk','Br','B',
                'Ca','Cd','Ce','Cf','Cl','Cm','Cn','Co','Cr','Cs','Cu','C','Db','Ds','Dy','Er',
                'Es','Eu','Fe','Fl','Fm','Fr','F','Ga','Gd','Ge','He','Hf','Hg','Ho','Hs','H',
                'In','Ir','I','Kr','K','La','Li','Lr','Lu','Lv','Mc','Md','Mg','Mn','Mo','Mt','Na',
                'Nb','Nd','Ne','Nh','Ni','No','Np','N','Os','O','Pa','Pb','Pd','Pm','Po','Pr','Pt',
                'Pu','P','Ra','Rb','Re','Rf','Rg','Rh','Rn','Ru','Sb','Sc','Se','Sg','Si','Sm','Sn',
                'Sr','S','Ta','Tb','Tc','Te','Th','Ti','Tl','Tm','Ts','U','V','W','Xe','Yb','Y','Zn','Zr']

class Geochemistryprocess():

    def __init__(self, iface):
        """Constructor."""
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n', 'Geochemistryprocess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Geochemistryprocess')
        self.toolbar = self.iface.addToolBar(u'Geochemistryprocess')
        self.toolbar.setObjectName(u'Geochemistryprocess')

        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        return QCoreApplication.translate('Geochemistryprocess', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def add_action_statistics(self, icon_path1, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path1)
        action1 = QAction(icon, text, parent)
        action1.triggered.connect(callback)
        action1.setEnabled(enabled_flag)

        if status_tip is not None:
            action1.setStatusTip(status_tip)
        if whats_this is not None:
            action1.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action1)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action1)

        self.actions.append(action1)
        return action1

    def add_action_layout(self, icon_path2, text, callback, enabled_flag=True, add_to_menu=True, add_to_toolbar=True, status_tip=None, whats_this=None, parent=None):
        icon = QIcon(icon_path2)
        action2 = QAction(icon, text, parent)
        action2.triggered.connect(callback)
        action2.setEnabled(enabled_flag)

        if status_tip is not None:
            action1.setStatusTip(status_tip)
        if whats_this is not None:
            action1.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.toolbar.addAction(action2)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action2)

        self.actions.append(action2)
        return action2

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/Geochemistryprocess/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Processing'),
            callback=self.run_drifting,
            parent=self.iface.mainWindow())
        icon_path1 = ':/plugins/Geochemistryprocess/icon_statistics.png'
        self.add_action_statistics(
            icon_path1,
            text=self.tr(u'Statistics'),
            callback=self.run_statistics,
            parent=self.iface.mainWindow())
        icon_path2 = ':/plugins/Geochemistryprocess/icon_layout.png'
        self.add_action_layout(
            icon_path2,
            text=self.tr(u'Layouts'),
            callback=self.run_layout,
            parent=self.iface.mainWindow())
                
        self.first_start = True


    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&Geochemistryprocess'),
                action)
            self.iface.removeToolBarIcon(action)
            
    def Exit(self):
        self.iface.messageBar().clearWidgets()

    def rejectDlg(self):
        self.dlg.close()

    def InstallOpenpyxl(self):
        mboxi.setWindowTitle("Установка")
        mboxi.setText('Готово')
        mboxi.show()
        pip.main(['install', 'Openpyxl'])
        pip.main(['install', 'xlrd'])
        return

    #--------------------------------------------------------------------------
    # Drifting
    #--------------------------------------------------------------------------    
    
    def neighbors_change_field(self):
        vlayer = self.dlg_drifting.Points_neighbor_CB.currentLayer()
        self.fieldList = []
        [self.fieldList.append(field.name()) for field in vlayer.fields()]
        self.items = QgsCheckableComboBox()
        self.items.addItems(self.fieldList)
        label = QtWidgets.QLabel()
        label.setText('Выбрать нужное поле')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()
        layout = QVBoxLayout()
        self.dlg.setWindowTitle("Field selection")
        self.dlg.resize(180, 100)
        layout.addWidget(label)
        layout.addWidget(self.items)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.neighbors)
        btnBox.rejected.connect(self.rejectDlg)
        layout.addWidget(btnBox)
        self.dlg.setLayout(layout)
        self.dlg.exec_()

    def edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c):
        x_plan = plan[-1].x()
        y_plan = plan[-1].y()
        dist = round(((x_fact - x_plan)**2 + (y_fact - y_plan)**2)**0.5, 3)
        if dist < dist_ctrl:
            name = plan[c]
            fact.insert(0, name)
            fact.insert(1, dist)
            copy = fact.copy()
            self.fin.append(copy)
            del fact[0]
            del fact[0]

    def neighbors(self):
        tic = time.perf_counter()
        self.dlg.close()
        check_field = self.items.checkedItems()[0]
        layer_list = [self.dlg_drifting.Points_CB.currentLayer(), self.dlg_drifting.Points_neighbor_CB.currentLayer()]
        crs = layer_list[0].crs()
        crs2 = layer_list[1].crs()
        if crs.authid() == "EPSG:4326" or crs2.authid() == "EPSG:4326" or crs.authid() != crs2.authid():
            mbox.setText("СК слоев должны быть прямоугольными и совпадать")
            mbox.show()
            mbox.exec_()
            return
        dist_ctrl = float(self.dlg_drifting.dist_ctrl.text())
        square_len = float(self.dlg_drifting.square_len.text())
        f0, f1 = layer_list[0].featureCount(), layer_list[1].featureCount()
        extent = layer_list[1].extent()
        xmax = extent.xMaximum() + 200
        ymax = extent.yMaximum() + 200
        xmin = extent.xMinimum() - 200
        ymin = extent.yMinimum() - 200
        len_a = xmax - xmin
        len_b = ymax - ymin
        rows = int(len_b // square_len + 1)
        cols = int(len_a // square_len + 1)
        square_count = rows * cols
        ff = f0
        fieldList = []
        fields_list = []
        Distarr = []
        [fieldList.append([field.name(), field.type()]) for field in layer_list[0].fields()]
        c = 0
        for field in layer_list[1].fields():
            c += 1
            if field.name() == check_field:
                break
        print('sc_cnt', square_count, 'a', len_a, 'b', len_b)


        f = f0 + f1
        ff = f
        # Reg and Facts points array
        for i in range(2):
            features = layer_list[i].getFeatures()
            fields = []
            for feature in features:
                ff -= 1
                if ff % 200 == 0:
                    self.dlg_drifting.progressBar.setValue(((f-ff)/f)*100)
                    self.dlg_drifting.progressBar.setFormat('Load Data: ' + str(int(((f-ff)/f)*100)) + ' %')
                    QApplication.processEvents()
                geom = feature.geometry()

                geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
                if geom.type() == QgsWkbTypes.PointGeometry:
                    if geomSingleType:
                        xy = geom.asPoint()
                        point = QgsPoint(xy)
                    else:
                        xy = geom.asMultiPoint()
                        point = QgsPoint(xy[0])

                attrs0 = feature.attributes()
                id = feature.id()
                attrs0.insert(0, id)
                attrs0.extend([point])
                fields.append(attrs0)
            fields_list.append(fields)

        # Squares with plans
        squares = []
        for _ in range(square_count):
            squares.append([])
        
        for plan in fields_list[1]:
            if ((xmin - dist_ctrl) < plan[-1].x() < (xmax + dist_ctrl)) and ((ymin - dist_ctrl) < plan[-1].y() < (ymax + dist_ctrl)):
                x_shift = plan[-1].x() - xmin
                y_shift = plan[-1].y() - ymin
                col = int(abs(x_shift // square_len) + 1)
                row = int(abs(y_shift // square_len) + 1)
                square_num = (row - 1) * cols + col
                squares[square_num - 1].append(plan)

        # Calc neighbors
        self.fin = []
        ff = f0

        for fact in fields_list[0]: # fact - Fact attrs, i - Plan attrs
            ff -= 1
            if ff % 200 == 0:
                self.dlg_drifting.progressBar.setValue(((f0-ff)/f0)*100)
                self.dlg_drifting.progressBar.setFormat('Calculation: ' + str(int(((f0-ff)/f0)*100)) + ' %')
                QApplication.processEvents()

            x_fact = fact[-1].x()
            y_fact = fact[-1].y()
            x_shift = x_fact - xmin
            y_shift = y_fact - ymin
            col = int(abs(x_shift // square_len) + 1)
            row = int(abs(y_shift // square_len) + 1)
            square_num = (row - 1) * cols + col

            # Edge conditions
            for plan in squares[square_num - 1]:
                Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # L
            if (square_len * (col-1) - dist_ctrl) < x_shift < (square_len * (col-1) + dist_ctrl) and square_num > 1:
                for plan in squares[square_num - 2]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # R
            if (square_len * col - dist_ctrl) < x_shift < (square_len * col + dist_ctrl) and square_num < square_count:
                for plan in squares[square_num]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # B
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for plan in squares[square_num - 1 - cols]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # T
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols:
                for plan in squares[square_num - 1 + cols]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # T - 1
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols:
                for plan in squares[square_num - 1 + cols - 1]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # T + 1
            if (square_len * (row) - dist_ctrl) < y_shift < (square_len * (row) + dist_ctrl) and square_num <= square_count - cols and square_num - 1 + cols + 1 < square_count:
                for plan in squares[square_num - 1 + cols + 1]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # B - 1
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for plan in squares[square_num - 1 - cols - 1]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
            # B + 1
            if (square_len * (row-1) - dist_ctrl) < y_shift < (square_len * (row-1) + dist_ctrl) and square_num > cols:
                for plan in squares[square_num - 1 - cols + 1]:
                    Geochemistryprocess.edge_conditions(self, dist_ctrl, fact, x_fact, y_fact, plan, c)
       
        #Create points layer
        pnt = QgsVectorLayer("Point", "Neighbors", "memory")
        pnt.setCrs(crs)
        pr = pnt.dataProvider()
        pr.addAttributes([QgsField(check_field, QVariant.String)])
        pr.addAttributes([QgsField('Dist', QVariant.Double)])
        for i in fieldList:
            pr.addAttributes([QgsField(i[0], i[1])])
        pnt.updateFields()
        fet = QgsFeature()
        
        # Remove dup
        self.fin.sort(key = lambda x: (x[2], x[1]))
        temp = []

        for i, val in enumerate(self.fin):
            if self.fin[i-1][2] != val[2]:
                temp.append(val)    
        self.fin = temp

        for i in self.fin:
            del i[2]

        # Create points
        f, ff = len(self.fin), len(self.fin)
        for i in self.fin:
            ff -= 1
            if ff % 1000 == 0:
                self.dlg_drifting.progressBar.setValue(((f-ff)/f)*100)
                self.dlg_drifting.progressBar.setFormat('Rendering: ' + str(int(((f-ff)/f)*100)) + ' %')
                QApplication.processEvents()
            attrs = []
            for field in range(len(i) - 1):
                attrs.extend([i[field]])
            fet.setGeometry(QgsPoint(i[-1].x(), i[-1].y()))
            fet.setAttributes(attrs)
            pr.addFeatures([fet])
        pnt.updateExtents()
        QgsProject.instance().addMapLayer(pnt)
        self.dlg_drifting.progressBar.setValue(0)
        self.dlg_drifting.progressBar.setFormat(None)

        toc = time.perf_counter()
        ttt = f"Время  {toc - tic:0.2f} сек"
        mboxi.setText(ttt + '\n' + "Количество точек: " + str(len(self.fin)))
        mboxi.show()
        mboxi.exec_()


    def MergeFiles(self):
        import xlrd
        from xlrd import XLRDError
        UnitName = self.dlg_drifting.UnitName.text()
        SampleName = self.dlg_drifting.SampleName.text()
        CustomSampleName = self.dlg_drifting.CustomSampleName.text()
        elements_iter = element_names.copy()
        file_path = self.dlg_drifting.mQgsFileWidget.filePath()
        file_paths = file_path.rsplit('"')
        for i in range(len(file_paths), -1, -1):
            if i % 2 == 0:
                del file_paths[i]
        file_paths = [file_path] if len(file_paths) == 0 else file_paths

        # def party
        parties = []
        for file in file_paths:
            simbol = ""
            dot_index = file.index('.')
            for i in range(dot_index-1, -1, -1):
                try:
                    condition = int(file[i])
                    simbol = simbol + file[i]
                except ValueError:
                    try:
                        part = int(simbol[::-1])
                    except ValueError:
                        mbox.setText('В конце названия файла должен быть номер партии')
                        mbox.show()
                        return
                    parties.append(part)
                    break

        # find all cols file
        ncols_arr = []
        for book in range(len(file_paths)):
            try:
                wb = xlrd.open_workbook(filename=file_paths[book])
            except xlrd.XLRDError:
                mbox.setText('Можно объединять только файлы экселя')
                mbox.show()
                return

            sheet = wb.sheet_by_index(0)
            ncols_arr.append(sheet.ncols)

        max_value = max(ncols_arr)
        max_index = ncols_arr.index(max_value)    

        wb = xlrd.open_workbook(filename=file_paths[max_index])
        sheet = wb.sheet_by_index(0)
        nrows = sheet.nrows
        ncols = sheet.ncols

        # def units names
        Unit_row = -1
        Sample_col = -1 
        CustomSample_col = -1
        cnt = 0
        for i in range(20):
            for j in range(ncols):
                cell_val = sheet.cell(i, j).value
                if type(cell_val) is str and cell_val.find(UnitName) != -1:
                    Unit_row = i
                if type(cell_val) is str and cell_val.find(SampleName) != -1 and Sample_col == -1:
                    Sample_row = i 
                    Sample_col = j 
                if type(cell_val) is str and cell_val.find(CustomSampleName) != -1 and CustomSample_col == -1:
                    CustomSample_row = i 
                    if j != Sample_col:
                        CustomSample_col = j 

        if Unit_row == -1:
            mbox.setText('Не найдена строка с единицами измерения')
            mbox.show()
            return
        if Sample_col == -1:
            mbox.setText('Не найден столбец с номером пробы')
            mbox.show()
            return
        if CustomSample_col == -1:
            mbox.setText('Не найден столбец с номером пробы клиента')
            mbox.show()
            return

        # def units
        Units = []
        for i in range(1, ncols):
            cell_val = sheet.cell(Unit_row, i).value
            if type(cell_val) is str and cell_val != "":
                Units.append(cell_val)

        # def elements
        elements = []
        cnt = -1
        for i in range(20):
            for j in range(ncols):
                cell_val = sheet.cell(i, j).value
                if type(cell_val) is str:
                    for elem in elements_iter: 
                        if cell_val.find(elem) != -1:
                            if len(cell_val) > 2 and len(cell_val) < 7:
                                if cell_val.find(elem + ' ') != -1 or cell_val.find(elem + '_') != -1:
                                    cnt += 1
                                    elements.append((elem, j, Units[cnt]))
                                    break
                            elif len(cell_val) == 2 and len(elem) == 1:
                                continue
                            elif len(cell_val) == 2 and len(elem) == 2:
                                cnt += 1
                                elements.append((elem, j, Units[cnt]))
                                break
                            elif len(cell_val) == 1 and len(elem) == 1:
                                cnt += 1
                                elements.append((elem, j, Units[cnt]))
                                break

        # def headers
        #elements.sort()
        Headers = []
        Headers.extend(("Batch", SampleName, CustomSampleName))
        for elem in elements:
            if elem[2].find("p") != -1 or elem[2].find("P") != -1:
                post = "_ppm"
            else:
                post = "_%"
            el = elem[0] + post
            Headers.extend([el]) 

        # MERGE BOOKS
        arr = []
        for book in range(len(file_paths)):
            self.dlg_drifting.progressBar.setValue(int((100/len(file_paths))*book))
            QApplication.processEvents()

            wb = xlrd.open_workbook(filename=file_paths[book])
            sheet = wb.sheet_by_index(0)
            nrows = sheet.nrows
            ncols = sheet.ncols

            # def samples
            cnt = -1
            Samples = []
            for i in range(Sample_row + 1, nrows):
                diff = 0
                cnt += 1
                cell_val = sheet.cell(i, Sample_col).value
                Samples.append(cell_val)
                if cnt > 0:
                    for j in range(len(Samples[cnt-1])):
                        try:
                            diff = diff if Samples[cnt][j] == Samples[cnt-1][j] else diff + 1
                        except IndexError:
                            break
                if diff > 3:
                    del Samples[-1]
                    break
    
            # def custom_samples
            CustomSamples = []
            for i in range(Sample_row + 1, Sample_row + 1 + len(Samples)):
                cell_val = sheet.cell(i, CustomSample_col).value
                CustomSamples.append(cell_val)
    
            # fin arr
            arrRow = []
            StartRow = Sample_row + 1
            cnt = -1
            coef_ppb = 1

            for row in range(StartRow, StartRow + len(Samples)):
                cnt += 1
                arrRow.append(parties[book])
                arrRow.append(Samples[cnt])
                arrRow.append(CustomSamples[cnt])
                for col in range(len(elements)):
                    try:
                        Unit_test_col = sheet.cell(Unit_row, elements[col][1]).value
                    except IndexError:
                        Unit_test_col = 'PPM'
                    if Unit_test_col.find("b") != -1 or Unit_test_col.find("B") != -1:
                        coef_ppb = 0.001
                    else:
                        coef_ppb = 1
                    try:
                        cell_val = sheet.cell(row, elements[col][1]).value
                    except IndexError:
                        cell_val = 'N/A'
                    try:
                        arrRow.append(float(cell_val) * coef_ppb)
                    except ValueError:
                        if cell_val.find("<") != -1:
                            while cell_val.find("<") != -1:
                                cell_val = cell_val[1:]
                            cell_val = str(float(cell_val) / 2)
                        elif cell_val.find(">") != -1:
                            while cell_val.find(">") != -1:
                                cell_val = cell_val[1:]
                        try:
                            arrRow.append(float(cell_val) * coef_ppb)
                        except ValueError:
                            arrRow.append("")

                arr.append(arrRow)
                arrRow = []

        # filling table
        self.dlg_drifting.tableWidget.setRowCount(len(arr)+1)
        self.dlg_drifting.tableWidget.setColumnCount(len(Headers))
        self.dlg_drifting.tableWidget.setHorizontalHeaderLabels(Headers)
        self.dlg_drifting.lcdRows.display(len(arr))
        self.dlg_drifting.lcdCols.display(len(elements))
        items = []

        self.head_table = []
        for i in range(len(Headers)):
            self.head_table.append(self.dlg_drifting.tableWidget.horizontalHeaderItem(i).text())
            CB = QtWidgets.QComboBox()
            CB.addItem("")
            CB.addItem("Batch")
            CB.addItem("Sample")
            items.append(CB)
            self.dlg_drifting.tableWidget.setCellWidget(0, i, items[i])

        for i in range(len(arr)):
            for j in range(len(Headers)):
                self.dlg_drifting.tableWidget.setItem(i+1, j, QTableWidgetItem(str(arr[i][j])))

        for i in range(self.dlg_drifting.CB_Element.count()):
            self.dlg_drifting.CB_Element.removeItem(0)

        for elem in elements:
            self.dlg_drifting.CB_Element.addItem(elem[0])
        self.dlg_drifting.progressBar.setValue(0)


    def select_batchs(self):
        polynum_degree = int(self.dlg_drifting.Polynom_degree.text())
        label = QtWidgets.QLabel()
        label.setText('Выбор элементов и партий для поправок')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()

        layout = QVBoxLayout()
        self.dlg.setWindowTitle("Batchs selection")
        self.dlg.resize(400, 1100)
        layout.addWidget(label)

        CB_elements = self.dlg_drifting.CB_Element
        elements = [CB_elements.itemText(i) for i in range(CB_elements.count())]

        col_cnt = self.dlg_drifting.tableWidget.columnCount()
        row_cnt = self.dlg_drifting.tableWidget.rowCount()
        for i in range(col_cnt):
            check_col = self.dlg_drifting.tableWidget.cellWidget(0, i).currentText()
            if check_col == "Batch":
                check_party = self.dlg_drifting.tableWidget.horizontalHeaderItem(i).text()
                batch_col = i
                break
        try:
            print(check_party, batch_col)
        except UnboundLocalError:
            mbox.setText('Нужно выбрать столбец с партиями')
            mbox.show()
            return

        batches = []
        for i in range(1, row_cnt):
            try:
                batches.append(int(self.dlg_drifting.tableWidget.item(i, batch_col).text()))
            except ValueError:
                mbox.setText('В столбце партий должны быть только целые числа')
                mbox.show()
                return

        batches = sorted(set(batches)) 
        new_batches = []
        for i, batch in enumerate(batches):
            new_batches.append(i+1)   

        polDegs = [0, 1, 2, 3, 4, 5]

        # Tree widget 
        self.tree = QTreeWidget()
        
        self.tree.setSelectionMode(3)
        self.tree.setColumnCount(1)
        self.tree.setHeaderLabels(['Элемент'])
        for i, elem in enumerate(elements):
            parent = QtWidgets.QTreeWidgetItem(self.tree) 
            self.tree.addTopLevelItem(parent)
            parent.setText(0, elem)
            if self.elem_settings[i] == 2:
                parent.setCheckState(0, QtCore.Qt.Checked)
            else:
                parent.setCheckState(0, QtCore.Qt.Unchecked)

            if self.batch_def == 0:
                for j, batch in enumerate(new_batches):
                    parent.addChild(QtWidgets.QTreeWidgetItem([str(batch)]))
                    parent.child(j).setCheckState(0, QtCore.Qt.Checked)
                    for k, deg in enumerate(polDegs):
                        parent.child(j).addChild(QtWidgets.QTreeWidgetItem([str(deg)]))
                        if k == polynum_degree:
                            parent.child(j).child(k).setCheckState(0, QtCore.Qt.Checked)
                        else:
                            parent.child(j).child(k).setCheckState(0, QtCore.Qt.Unchecked)
            else:
                for j, batch in enumerate(new_batches):
                    parent.addChild(QtWidgets.QTreeWidgetItem([str(batch)]))
                    if self.batches_settings[i][j] == 2:
                        parent.child(j).setCheckState(0, QtCore.Qt.Checked)
                    else:
                        parent.child(j).setCheckState(0, QtCore.Qt.Unchecked)

                    for k, deg in enumerate(polDegs):
                        parent.child(j).addChild(QtWidgets.QTreeWidgetItem([str(deg)]))
                        b_child = parent.child(j)
                        if self.deg_settings[i][j][k] == 2:
                            b_child.child(k).setCheckState(0, QtCore.Qt.Checked)
                        else:
                            b_child.child(k).setCheckState(0, QtCore.Qt.Unchecked)

        self.ch = 1
        self.ch_0 = 1
        self.ch_1 = 1
        self.tree.itemChanged[QTreeWidgetItem, int].connect(self.get_item) # signal change checks
        btn = QPushButton('Check all elements')
        btn.clicked.connect(self.select_batchs_check_elems)
        layout.addWidget(btn) 

        bnt_batches = QPushButton('Check all batches')
        bnt_batches.clicked.connect(self.select_batchs_check_batches)
        layout.addWidget(bnt_batches)

        bnt_selected = QPushButton('Check selected')
        bnt_selected.clicked.connect(self.select_batchs_check_selected)
        layout.addWidget(bnt_selected)

        layout.addWidget(self.tree)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)

        btnBox.accepted.connect(self.select_batchs_OK)
        btnBox.rejected.connect(self.rejectDlg)
        
        layout.addWidget(btnBox)
        self.dlg.setLayout(layout)
        self.dlg.exec_()

    def get_item(self):
        root = self.tree.invisibleRootItem()


        for i in range(root.childCount()):
            elem = root.child(i)
            for j in range(elem.childCount()):
                batch = elem.child(j)
                degs = []
                summ = 0
                for k in range(batch.childCount()):
                    deg = batch.child(k)
                    summ += deg.checkState(0)
                    if summ > 2:
                        pass
                    deg.checkState(0)

        if root.child(0).checkState(0) == Qt.Checked:
            print(f'{root.child(0).checkState(0)} was checked')
        else:
            print(f'{root.child(0).checkState(0)} was unchecked')

    def select_batchs_check_elems(self):
        root = self.tree.invisibleRootItem()
        elem_count = root.childCount()
        self.ch += 1
        if self.ch % 2 == 0:
            for i in range(elem_count):
                item = root.child(i)
                item.setCheckState(0, QtCore.Qt.Unchecked)
        else:
            for i in range(elem_count):
                item = root.child(i)
                item.setCheckState(0, QtCore.Qt.Checked)

    def select_batchs_check_batches(self):
        root = self.tree.invisibleRootItem()
        elem_count = root.childCount()
        item = root.child(0)
        batches_count = item.childCount()

        self.ch_0 += 1
        if self.ch_0 % 2 == 0:
            for i in range(elem_count):
                item = root.child(i)
                for j in range(item.childCount()):
                    item.child(j).setCheckState(0, QtCore.Qt.Unchecked)
        else:
            for i in range(elem_count):
                item = root.child(i)
                for j in range(item.childCount()):
                    item.child(j).setCheckState(0, QtCore.Qt.Checked)

    def select_batchs_check_selected(self):
        list_selected = self.tree.selectedItems()

        self.ch_1 += 1
        if self.ch_1 % 2 == 0:
            for item in list_selected:
                item.setCheckState(0, QtCore.Qt.Unchecked)
        else:
            for item in list_selected:
                item.setCheckState(0, QtCore.Qt.Checked)

    def select_batchs_OK(self):
        # save settings
        self.batch_def = 1
        self.elem_settings = []
        self.batches_settings = []
        self.deg_settings = []
        self.deg_trends = []
        root = self.tree.invisibleRootItem()
        child_count = root.childCount()

        for i in range(child_count):
            elem = root.child(i)
            batchs = []
            degs_b = []

            for j in range(elem.childCount()):
                batch = elem.child(j)
                batchs.append(batch.checkState(0))
                degs = []

                for k in range(batch.childCount()):
                    deg = batch.child(k)
                    degs.append(deg.checkState(0))
                degs_b.append(degs)

            self.elem_settings.append(elem.checkState(0))
            self.batches_settings.append(batchs)
            self.deg_settings.append(degs_b)

        for el in self.deg_settings:
            a = []
            for ba in el:
                cnt = -1
                for de in ba:
                    cnt += 1
                    if de == 2:
                        a.append(cnt)
                        break
            self.deg_trends.append(a)

        self.dlg.close()

       
    def Drifting(self):
        file_path = self.dlg_drifting.mQgsFileWidget.filePath()
        file_paths = file_path.rsplit('"')
        for i in range(len(file_paths), -1, -1):
            if i % 2 == 0:
                del file_paths[i]
        file_paths = [file_path] if len(file_paths) == 0 else file_paths
        directory = os.path.dirname(file_paths[0])
        element = self.dlg_drifting.CB_Element.currentText()
        current_elem_index = self.dlg_drifting.CB_Element.currentIndex()
        plot_num = int(self.dlg_drifting.Plots_num.text())
        polynum_degree = int(self.dlg_drifting.Polynom_degree.text())
        fontsize = int(self.dlg_drifting.ticks_font_size.text())
        color = "black"
        dpi = int(self.dlg_drifting.dpi.text())
        elements_iter = element_names.copy()
        if not self.dlg_drifting.checkBox.isChecked():
            elements_iter = [element]
        keys = []
        elements = []
        elements_cols = []
        content = []
        parties = []
        probs = []
        data = []
        logs_elems_ish = []
        logs_elems_isp = []
        fin_data_ish = []
        fin_data_isp = []
        col_cnt = self.dlg_drifting.tableWidget.columnCount()
        row_cnt = self.dlg_drifting.tableWidget.rowCount()
        data_col = []
        check_party = 'none'
        check_prob = 'none'
        for i in range(col_cnt):
            data_col.append('Head')
            check_col = self.dlg_drifting.tableWidget.cellWidget(0, i).currentText()
            keys.append(self.dlg_drifting.tableWidget.horizontalHeaderItem(i).text())
            if check_col == "Batch":
                check_party = self.dlg_drifting.tableWidget.horizontalHeaderItem(i).text()
            if check_col == "Sample":
                check_prob = self.dlg_drifting.tableWidget.horizontalHeaderItem(i).text()
        data.append(data_col)
        data_col = []
        for i in range(1, row_cnt):
            for j in range(col_cnt):
                data_col.append(self.dlg_drifting.tableWidget.item(i, j).text())
            data.append(data_col)
            data_col = []

        data_np = np.array(data)

        # Calc Log ish data
        for i in range(col_cnt):
            party = keys[i]
            prob = keys[i]
            if party == check_party:
                party_col = i
            if prob == check_prob:
                prob_col = i
            for elem in elements_iter:
                if keys[i].find(elem) != -1:
                    if len(keys[i]) > 2 and len(keys[i]) < 7:
                        if keys[i].find(elem + ' ') != -1 or keys[i].find(elem + '_') != -1:
                            elements.append(elem)
                            elements_cols.append(i)
                            cont = keys[i].rsplit('_', 2)
                            content.append(cont[-1])
                            for k in range(1, len(data)):
                                try:
                                    logs_elems_ish.append(round(math.log10(float(data[k][i])), 5))
                                except ValueError:
                                    continue
                            fin_data_ish.append(logs_elems_ish)
                            logs_elems_ish = []
                            elements_iter.remove(elem)
                            break
                    elif len(keys[i]) == 2 and len(elem) == 1:
                        continue
                    elif len(keys[i]) == 2 and len(elem) == 2:
                        elements.append(elem)
                        elements_cols.append(i)
                        cont = keys[i].rsplit('_', 2)
                        content.append(cont[-1])
                        for k in range(1, len(data)):
                            try:
                                logs_elems_ish.append(round(math.log10(float(data[k][i])), 5))
                            except ValueError:
                                continue
                        fin_data_ish.append(logs_elems_ish)
                        logs_elems_ish = []
                        elements_iter.remove(elem)
                        break
                    elif len(keys[i]) == 1 and len(elem) == 1:
                        elements.append(elem)
                        elements_cols.append(i)
                        cont = keys[i].rsplit('_', 2)
                        content.append(cont[-1])
                        for k in range(1, len(data)):
                            try:
                                logs_elems_ish.append(round(math.log10(float(data[k][i])), 5))
                            except ValueError:
                                continue
                        fin_data_ish.append(logs_elems_ish)
                        logs_elems_ish = []
                        elements_iter.remove(elem)
                        break

        # Define range parties for elements
        parties_elem = []
        probs_elem = []
        if check_party != 'none':
            for elem in range(len(elements)):
                cnt = -1
                for i in range(1, len(data)):
                    cnt += 1
                    if data[i][elements_cols[elem]] != "":
                        try:
                            parties_elem.append(int(data[i][party_col]))
                        except ValueError:
                            mbox.setText('В столбце с партией (Party) должны быть только целые числа')
                            mbox.show()
                            return
                        if check_prob != 'none':
                            probs_elem.append(str(data[i][prob_col]))
                        else:
                            probs_elem.append(cnt)
                parties.append(parties_elem)
                probs.append(probs_elem)
                parties_elem = []
                probs_elem = []
        else:
            for elem in range(len(elements)):
                cnt = -1
                for i in range(1, len(data)):
                    cnt += 1
                    if data[i][elements_cols[elem]] != "":
                        parties_elem.append(0)
                        if check_prob != 'none':
                            probs_elem.append(str(data[i][prob_col]))
                        else:
                            probs_elem.append(cnt)
                parties.append(parties_elem)
                probs.append(probs_elem)
                parties_elem = []
                probs_elem = []  

        parties0 = []
        probs0 = []
        cnt = -1
        for i in range(1, len(data)):
            cnt += 1
            if check_party != 'none':
                parties0.append(int(data[i][party_col]))
            else:
                parties0.append(1)
            if check_prob != 'none':
                probs0.append(str(data[i][prob_col]))
            else:
                probs0.append(cnt)

        # All means
        mean_all = []
        for i in range(len(elements)):
            mean_all.append(np.mean(fin_data_ish[i]))

        # Calc batch indexes
        batch_index = []
        
        if len(self.deg_trends) != 0:            # for multi elem
            for i in range(len(self.deg_trends)):
                ba_in = []
                cnt = -1
                for j in range(1, len(parties[0])):
                    if parties[0][j] != parties[0][j-1]:
                        cnt += 1
                        ba_in.append(self.deg_trends[i][cnt])
                    else:
                        ba_in.append('')
                ba_in.append(self.deg_trends[i][-1])
                batch_index.append(ba_in)


        # Calc party trends 
        trend_part = []
        trend_part_el = []
        cnt = 0

        for i in range(len(elements)):
            for j in range(len(parties[i])):
                if j == len(parties[i])-1: # Last party
                    range_party = np.arange(0, j-cnt+1)
                    if len(self.deg_trends) != 0 and len(elements) == 1:
                        polynum_degree = batch_index[current_elem_index][j]
                    elif len(self.deg_trends) != 0 and len(elements) != 1:
                        polynum_degree = batch_index[i][j]
                    try:
                        trend_part_el.append((np.polyval(np.polyfit(range_party, fin_data_ish[i][cnt:j+1], polynum_degree), range_party)).tolist()) # trend party
                    except ValueError:
                        trend_part_el.append((np.polyval(np.polyfit(range_party, fin_data_ish[i][cnt:j+1], 0), range_party)).tolist())
                    except TypeError:
                        mbox.setText('В столбце с данными присутствуют текстовые символы')
                        mbox.show()
                        return
                    break
                if parties[i][j+1] != parties[i][j]: # New party
                    range_party = np.arange(0, j-cnt+1)
                    if len(self.deg_trends) != 0 and len(elements) == 1:
                        polynum_degree = batch_index[current_elem_index][j]
                    elif len(self.deg_trends) != 0 and len(elements) != 1:
                        polynum_degree = batch_index[i][j]
                    try:
                        trend_part_el.append((np.polyval(np.polyfit(range_party, fin_data_ish[i][cnt:j+1], polynum_degree), range_party)).tolist()) # trend party
                    except ValueError:
                        trend_part_el.append((np.polyval(np.polyfit(range_party, fin_data_ish[i][cnt:j+1], 0), range_party)).tolist())
                    except TypeError:
                        mbox.setText('В столбце с данными присутствуют текстовые символы')
                        mbox.show()
                        return
                    cnt = j+1
            trend_part.append(trend_part_el)
            trend_part_el = []
            cnt = 0


        # Define ticks labels
        party_ticksNum = []
        party_ticksVal = []

        party_ticksNum.append(0)
        party_ticksVal.append((parties[0][0]))
        for j in range(len(parties[0])):
            if j == len(parties[0])-1: # Last party
                break
            if parties[0][j+1] != parties[0][j]: # New party
                party_ticksNum.append(j+1)
                party_ticksVal.append(parties[0][j+1])
        if sum(parties[0]) == 0:  # if not party
            party_ticksNum = []
            party_ticksVal = []

        # Centered ticks labels
        batch_ticks_center = []
        if sum(parties[0]) != 0:
            for i in range(1, len(party_ticksNum)):
                pos_label_batch = party_ticksNum[i-1] + (party_ticksNum[i] - party_ticksNum[i-1]) / 2
                batch_ticks_center.append(pos_label_batch)
            batch_ticks_center.append(party_ticksNum[-1] + (row_cnt - party_ticksNum[-1]) / 2)
        #---------------------------------

        partyLong_ticksNum = []
        partyLong_ticksVal = []
        for i in range(1, len(party_ticksVal)):
            if party_ticksVal[i] > party_ticksVal[i-1] + 9:
                partyLong_ticksNum.append(party_ticksNum[i])
                partyLong_ticksVal.append(party_ticksVal[i])

        # Final data array 
        trend = []
        trend_fin = []

        for elem in range(len(elements)): # Calc trend
            cnt = -1
            cnt_part = -1
            for party_n in trend_part[elem]:
                cnt_part += 1
                for item in party_n:
                    cnt += 1
                    trend.append(item)
                    if len(self.batches_settings) != 0:
                        if len(elements) != 1:
                            if self.elem_settings[elem] == 2 and self.batches_settings[elem][cnt_part] == 2:
                                log_el_isp = fin_data_ish[elem][cnt] - item + mean_all[elem]
                            else:
                                log_el_isp = fin_data_ish[elem][cnt]
                        else:
                            if self.elem_settings[current_elem_index] == 2 and self.batches_settings[current_elem_index][cnt_part] == 2:
                                log_el_isp = fin_data_ish[elem][cnt] - item + mean_all[elem]
                            else:
                                log_el_isp = fin_data_ish[elem][cnt]
                    else:
                        log_el_isp = fin_data_ish[elem][cnt] - item + mean_all[elem]
                    logs_elems_isp.append(round(log_el_isp, 5)) # Calc isp
            fin_data_isp.append(logs_elems_isp)
            logs_elems_isp = []
            trend_fin.append(trend)
            trend = []
        if elements == []:
            mbox.setText(element + ' not in file')
            mbox.show()
            print(element, 'not in file')

        # Export dreif data to file
        if len(elements) > 1:
            merge_table = []
            strr = 'Batch' + '\t' + 'Batch_N' + '\t' + 'Sample' 
            for elem in elements:
                strr = strr + '\t' + 'Lg_' + elem  + '_исх'
                strr = strr + '\t' + 'Lg_' + elem  + '_испр'
            strr += '\n'
            if directory == "":
                mbox.setText('Не выбрана директория для сохранения')
                mbox.show()
                return
            with open(directory + '/' + 'dreif_data.txt', 'w', encoding = 'Windows-1251') as f:
                f.write(strr)
    
            compare_ish = []
            compare_isp = []
            parties0_new =[1]
            cnt = 1
            for i in range(1, len(parties0)):
                if parties0[i] == parties0[i-1]:
                    parties0_new.append(cnt)
                else:
                    cnt+=1
                    parties0_new.append(cnt)

            merge_table.append(parties0)
            merge_table.append(parties0_new)
            merge_table.append(probs0)

            cnt = 0
            range_cnt = 0
            for elem in range(len(elements)):
                data_cnt = -1
                range_cnt = 0
                for i in range(len(probs0)):
                    self.dlg_drifting.progressBar.setValue(int((50 / len(elements)) * elem))
                    QApplication.processEvents()
                    for j in probs[elem]:
                        cnt += 1
                        data_cnt += 1
                        if probs0[i] == j:
                            compare_ish.append(fin_data_ish[elem][data_cnt])
                            compare_isp.append(fin_data_isp[elem][data_cnt])
                            del probs[elem][0]
                            cnt = 0
                            break
                        elif cnt == len(probs[elem]):
                            range_cnt += 1
                            compare_ish.append("")
                            compare_isp.append("")
                            cnt = 0
                            data_cnt = i - range_cnt 
                merge_table.append(compare_ish)
                merge_table.append(compare_isp)
                compare_ish = []
                compare_isp = []
            arr = np.array(merge_table)
            arr_T = arr.transpose()
            
            with open(directory + '/' + 'dreif_data.txt', "a+") as f:
                np.savetxt(f, arr_T, delimiter = '\t', fmt='%s')


        # Graphics
        y_ticks = [ 0.00001, 0.00002, 0.00003, 0.00004, 0.00005, 0.00006, 0.00007, 0.00008, 0.00009,
                    0.0001, 0.0002, 0.0003, 0.0004, 0.0005, 0.0006, 0.0007, 0.0008, 0.0009,
                    0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.007, 0.008, 0.009,
                    0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09,
                    0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9,
                    1, 2, 3, 4, 5, 6, 7, 8, 9,
                    10, 20, 30, 40, 50, 60, 70, 80, 90,
                    100, 200, 300, 400, 500, 600, 700, 800, 900,
                    1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000,
                    10000, 20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000,
                    100000, 200000, 300000, 400000, 500000, 600000, 700000, 800000, 900000]

        y_ticks_labels = [  0.00001, 0.00002, '', '', 0.00005, '', '', '', '',
                            0.0001, 0.0002, '', '', 0.0005, '', '', '', '',
                            0.001, 0.002, '', '', 0.005, '', '', '', '',
                            0.01, 0.02, '', '', 0.05, '', '', '', '',
                            0.1, 0.2, '', '', 0.5, '', '', '', '',
                            1, 2, '', '', 5, '', '', '', '',
                            10, 20, '', '', 50, '', '', '', '',
                            100, 200, '', '', 500, '', '', '', '',
                            1000, 2000, '', '', 5000, '', '', '', '',
                            10000, 20000, '', '', 50000, '', '', '', '',
                            100000, 200000, '', '', 500000, '', '', '', '']

        xticks_all = []
        ticks_len_all = int(self.dlg_drifting.ticks_len.text())
        for i in range(int(row_cnt/ticks_len_all)):
            xticks_all.append(i*ticks_len_all)
        xticks_all.append(int(row_cnt/ticks_len_all)*ticks_len_all)

        new_batch_num = []
        for i in range(len(party_ticksVal)):
            new_batch_num.append(i+1)

        x = []
        xy = []
        xy_unlog = []

        for elem in range(len(elements)):

            # Построение графиков
            split_ish = np.array_split(np.array(fin_data_ish[elem]), plot_num, axis = 0) # Graphic 1
            split_isp = np.array_split(np.array(fin_data_isp[elem]), plot_num, axis = 0) # Graphic 2
            split_trend = np.array_split(np.array(trend_fin[elem]), plot_num, axis = 0)  # Graphic 3

            data_unlog = []
            for i in fin_data_ish[elem]:
                data_unlog.append(10**i)
            split_unlog = np.array_split(np.array(data_unlog), plot_num, axis = 0)

            min_unlog = min(data_unlog)
            max_unlog = max(data_unlog)

            min_val_e = [min(fin_data_ish[elem]), min(fin_data_isp[elem])] # Y limits
            max_val_e = [max(fin_data_ish[elem]), max(fin_data_ish[elem])]
            min_val = min(min_val_e) - 0.0001
            max_val = max(max_val_e) + 0.0001
            min_val_r = math.floor(min_val*5)/5 
            max_val_r = math.ceil(max_val*5)/5

            fig, axs = plt.subplots(plot_num, 1, figsize=[25, 12]) # Figure
            plt.subplots_adjust(top=0.97, bottom=0.06, left=0.04, right=0.90, hspace=plot_num*0.025)

            cnt = 0
            for i in range(plot_num):
                x.append(np.linspace(cnt, cnt + len(split_ish[i]) - 1, len(split_ish[i])))
                xy.append([x[i], split_ish[i], split_isp[i], split_trend[i]])
                xy_unlog.append([x[i], split_unlog[i]])
                cnt += len(split_ish[i])

            if plot_num == 1:
                ax2 = axs.twinx()
                axs.plot(xy[0][0], xy[0][2], linewidth=0.8, label='Исправленные', color='tab:blue')
                axs.plot(xy[0][0], xy[0][1], linewidth=0.8, label='Исходные', color='tab:orange')
                axs.plot(xy[0][0], xy[0][3], linewidth=0.6, label='Тренд', color='tab:green')
                ticks = axs.set_xticks(xticks_all)
                labels = axs.set_xticklabels(xticks_all, fontsize=fontsize)
                ticks1 = axs.set_xticks(batch_ticks_center, minor=True)
                labels1 = axs.set_xticklabels(new_batch_num, minor=True, fontsize=fontsize+2, fontname="Arial", style='italic', color='r')
                for lnum, label in enumerate(labels1):
                    label.set_y(label.get_position()[1] + 0.025 * plot_num)

                for line in party_ticksNum:
                    axs.axvline(x = line, color = 'r', linestyle='--', linewidth=0.8, label = 'axvline - full height')
                for line in partyLong_ticksNum:
                    axs.axvline(x = line, color = 'black', label = 'axvline - full height')

                handles, labels = axs.get_legend_handles_labels()
                axs.set_xlim(0, len(split_ish[0])-1)
                axs.set_ylim(min_val_r, max_val_r)
                axs.tick_params(axis='y', labelsize=fontsize)
                axs.tick_params(which='minor', axis='x', bottom = False)
                axs.yaxis.set_label_position('right')
                axs.yaxis.tick_right()
                # ax unlog
                ax2.plot(xy_unlog[0][0], xy_unlog[0][1], linestyle='None')
                ax2.yaxis.set_label_position('left')
                ax2.yaxis.tick_left()
                ax2.set_yscale('log')
                ax2.set_yticks(y_ticks)
                ax2.set_yticklabels(y_ticks_labels, fontsize=fontsize)
                ax2.set_ylim(10**min_val_r, 10**max_val_r)
            else:
                cnt = 0
                for i in range(plot_num):
                    QApplication.processEvents()
                    ax2 = axs[i].twinx()
                    pl_1 = axs[i].plot(xy[i][0], xy[i][2], linewidth=0.8, label='Исправленные', color='tab:blue')
                    pl_2 = axs[i].plot(xy[i][0], xy[i][1], linewidth=0.8, label='Исходные', color='tab:orange')
                    pl_3 = axs[i].plot(xy[i][0], xy[i][3], linewidth=0.6, label='Тренд', color='tab:green')
                    ticks = axs[i].set_xticks(xticks_all)
                    labels = axs[i].set_xticklabels(xticks_all, fontsize=fontsize)
                    ticks1 = axs[i].set_xticks(batch_ticks_center, minor=True)
                    labels1 = axs[i].set_xticklabels(new_batch_num, minor=True, fontsize=fontsize+2, fontname="Arial", style='italic', color='r')
                    for lnum, label in enumerate(labels1):
                        label.set_y(label.get_position()[1] + 0.025 * plot_num)

                    for line in party_ticksNum:
                        axs[i].axvline(x = line, color = 'r', linestyle='--', linewidth=0.8, label = 'axvline - full height')
                    for line in partyLong_ticksNum:
                        axs[i].axvline(x = line, color = 'black', label = 'axvline - full height')

                    axs[i].set_xlim(cnt, cnt + len(split_ish[i])-1)
                    axs[i].set_ylim(min_val_r, max_val_r)
                    axs[i].tick_params(axis='y', labelsize=fontsize)
                    axs[i].tick_params(which='minor', axis='x', bottom = False)
                    axs[i].yaxis.set_label_position("right")
                    axs[i].yaxis.tick_right()
                    # ax y unlog
                    ax2.plot(xy_unlog[i][0], xy_unlog[i][1], linestyle='None')
                    ax2.yaxis.set_label_position("left")
                    ax2.yaxis.tick_left()
                    ax2.set_yscale('log')
                    ax2.set_yticks(y_ticks)
                    ax2.set_yticklabels(y_ticks_labels, fontsize=fontsize)
                    ax2.set_ylim(10**min_val_r, 10**max_val_r)
                    cnt += len(split_ish[i])
                handles, labels = axs[0].get_legend_handles_labels()
            
            fig.text(0.5, 0.024, 'Номер aнализа по порядку его выполнения', fontsize=14, color=color, ha='center')
            fig.text(0.015, 0.5, elements[elem]+', '+content[elem], va='center', rotation='vertical', fontsize=14, color=color)
            fig.text(0.92, 0.5, 'lg '+elements[elem], va='center', rotation='vertical', fontsize=14, color=color)

            rect = plt.Rectangle((0.01, 0.01), 0.98, 0.98, fill=False, color="k", lw=1, zorder=1000, transform=fig.transFigure, figure=fig)
            fig.patches.extend([rect])


            marker_obj = mpl.markers.MarkerStyle('$?$') 
            path = marker_obj.get_path().transformed(marker_obj.get_transform())
            patch = mpl.patches.PathPatch(path, facecolor="cornflowerblue", lw=2, label='Порядок серии')


            if sum(parties[0]) != 0:
                legend_elements = [ Line2D([0], [0], color='tab:orange', lw=1, label='Исходные'),
                                    Line2D([0], [0], color='tab:blue', lw=1, label='Исправленные'),
                                    Line2D([0], [0], color='tab:green', lw=1, label='Тренд'),
                                    Line2D([0], [0], color='black', lw=1, label='Границы групп'),
                                    Line2D([0], [0], color='r', lw=1, linestyle='--', label='Границы серий'),
                                    Line2D([0], [0], color='r', lw=0, marker='$1$', markeredgewidth=0, markersize=7, label='Порядок серии')]
            else:
                legend_elements = [ Line2D([0], [0], color='tab:orange', lw=1, label='Исходные'),
                                    Line2D([0], [0], color='tab:blue', lw=1, label='Исправленные'),
                                    Line2D([0], [0], color='tab:green', lw=1, label='Тренд')]

            fig.legend(handles=legend_elements, loc=(0.92, 0.86), framealpha=1.0, frameon=True)


            x = []
            xy = []
            if not self.dlg_drifting.checkBox.isChecked():
                plt.show()
                return
            else:
                plt.savefig(directory + '/' + elements[elem], dpi=dpi)
                plt.close()
                plt.clf()
            self.dlg_drifting.progressBar.setValue(int(50 + (50/len(elements))*elem))
            QApplication.processEvents()
            print(elements[elem])        
        self.dlg_drifting.progressBar.setValue(0)


    def Update(self):
        file_path = self.dlg_drifting.mQgsFileWidget.filePath()
        data = []
        
        try:
            with open(file_path, 'r', encoding = 'Windows-1251') as file:
                lines = file.readlines()
            for i in range(len(lines)):
                line = lines[i].replace('\n','').split('\t')
                data.append(line)
        except FileNotFoundError:
            fieldList = []
            layer = self.iface.activeLayer()
            [fieldList.append(field.name()) for field in layer.fields()]
            features = layer.getFeatures()
            data.append(fieldList)
            for feature in features:
                attrs = feature.attributes()
                strAttrs = []
                for attr in attrs:
                    strAttrs.append(str(attr))
                data.append(strAttrs)


        self.head_table = []
        [self.head_table.append(el) for el in data[0]]
        self.dlg_drifting.tableWidget.setRowCount(len(data))
        self.dlg_drifting.tableWidget.setColumnCount(len(data[0]))
        self.dlg_drifting.tableWidget.setHorizontalHeaderLabels(data[0])
        for j in range(len(data[0])):
            CB = QtWidgets.QComboBox()
            CB.addItem("")
            CB.addItem("Batch")
            CB.addItem("Sample")
            self.dlg_drifting.tableWidget.setCellWidget(0, j, CB)

        # Define elements in table
        elements_iter = element_names.copy()
        col_cnt = self.dlg_drifting.tableWidget.columnCount()
        for i in range(self.dlg_drifting.CB_Element.count()):
            self.dlg_drifting.CB_Element.removeItem(0)
        for i in range(col_cnt):
            for j in range(len(elements_iter)):
                if data[0][i].find(elements_iter[j]) != -1:
                    if len(data[0][i]) > 2:
                        if data[0][i].find(elements_iter[j] + ' ') != -1 or data[0][i].find(elements_iter[j] + '_') != -1:
                            self.dlg_drifting.CB_Element.addItem(elements_iter[j])
                            del elements_iter[j]
                            break
                    elif len(data[0][i]) == 2 and len(elements_iter[j]) == 1:
                        continue
                    elif len(data[0][i]) == 2 and len(elements_iter[j]) == 2:
                        self.dlg_drifting.CB_Element.addItem(elements_iter[j])
                        del elements_iter[j]
                        break
                    else:
                        self.dlg_drifting.CB_Element.addItem(elements_iter[j])
                        del elements_iter[j]
                        break

        elements_cnt = self.dlg_drifting.CB_Element.count()
        self.elem_settings = [] # settings batch tree - elements
        self.batches_settings = [] # settings batch tree - batches
        self.deg_settings = [] # settings batch tree - degs
        self.deg_trends = []
        self.batch_def = 0 # start batch define
        for i in range(elements_cnt):
            self.elem_settings.append(2)
        self.dlg_drifting.lcdRows.display(len(data)-1)
        self.dlg_drifting.lcdCols.display(elements_cnt)

        # Update Table
        f = len(data) * len(self.head_table)
        ff = f
        for i in range(1, len(data)):
            for j in range(len(data[0])):
                ff -= 1
                if ff % 200 == 0:
                    self.dlg_drifting.progressBar.setValue(((f - ff)/f)*100)
                    QApplication.processEvents()
                self.dlg_drifting.tableWidget.setItem(i, j, QTableWidgetItem(data[i][j]))
        self.dlg_drifting.progressBar.setValue(0)

    def Correct(self):
        keys = []
        data = []
        MinSamples = int(self.dlg_drifting.MinSamples.text()) - 1 
        file_path = self.dlg_drifting.mQgsFileWidget.filePath()
        file_paths = file_path.rsplit('"')

        if file_path == '':
            layer = self.iface.activeLayer()
            pr = layer.dataProvider()
            file_path = pr.dataSourceUri()

        for i in range(len(file_paths), -1, -1):
            if i % 2 == 0:
                del file_paths[i]
        file_paths = [file_path] if len(file_paths) == 0 else file_paths
        directory = os.path.dirname(file_paths[0])
        col_cnt = self.dlg_drifting.tableWidget.columnCount()
        row_cnt = self.dlg_drifting.tableWidget.rowCount()
        data_col = []

        if self.dlg_drifting.tableWidget.horizontalHeaderItem(col_cnt-1).text() == "":
            for i in range(1, col_cnt):
                if not self.dlg_drifting.tableWidget.item(i, col_cnt-1).text() == "":
                    for j in range(col_cnt):
                        keys.append(self.dlg_drifting.tableWidget.item(i, j).text())
                    break
        else:
            for k in range(col_cnt):
                keys.append(self.dlg_drifting.tableWidget.horizontalHeaderItem(k).text())

        for i in range(1, row_cnt):
            for j in range(col_cnt):
                data_col.append(self.dlg_drifting.tableWidget.item(i, j).text())
            data.append(data_col)
            data_col = []

        vals = []
        for i in keys:
            vals.append([])

        # Correct vals
        cnt = 0
        compare = keys
        f = col_cnt * row_cnt
        ff = f
        for row in range(row_cnt - 1):
            cnt += 1
            for i in range(len(keys)):
                ff -= 1
                if ff % 200 == 0:
                    self.dlg_drifting.progressBar.setValue(((f-ff)/f)*66.6)
                    QApplication.processEvents()
                for j in range(len(compare)):
                    if keys[i] == compare[j]:
                        if not keys[i] in data[row] and not data[row][i] in keys:
                            vals[i].extend([data[row][j]])
                            break
                        else:
                            compare = data[row]
                            while "" in compare:
                                compare.remove('')
                            cnt = 0
                            break
                    else:
                        if j == len(compare)-1:
                            vals[i].extend([''])
                            break
                if cnt == 0:
                    break

        # Del empty data
        empty_cols = []
        empty_cols_num = []
        for col in range(len(vals)):
            empty_cols.append(vals[col].count(""))
        cnt = -1
        for cols in vals:
            cnt += 1
            if empty_cols[cnt] >= len(cols) - MinSamples:
                empty_cols_num.append(cnt)
        cnt = -1
        for i in empty_cols_num:
            cnt += 1
            dup = keys[i-cnt]
            del keys[i-cnt]
            del vals[i-cnt]
            try:
                if keys[i-cnt].find(dup+"") != -1 or keys[i-cnt].find(dup+"_") != -1:
                    del keys[i-cnt]
                    del vals[i-cnt]
                    cnt += 1
            except IndexError:
                mbox.setText('Минимальное количество строк на выходе больше количества строк в таблице')
                mbox.show()
                return

        # def elements
        elements = []
        elements_iter = element_names.copy()
        elem_cols = []
        cnt = -1
        for key in keys:
            cnt += 1
            for elem in elements_iter: 
                if key.find(elem) != -1:
                    if len(key) > 2 and len(key) < 7:
                        if key.find(elem + ' ') != -1 or key.find(elem + '_') != -1:
                            elements.append(elem)
                            elem_cols.append(cnt)
                            elements_iter.remove(elem)
                            break
                    elif len(key) == 2 and len(elem) == 1:
                        continue
                    elif len(key) == 2 and len(elem) == 2:
                        elements.append(elem)
                        elem_cols.append(cnt)
                        elements_iter.remove(elem)
                        break
                    elif len(key) == 1 and len(elem) == 1:
                        elements.append(elem)
                        elem_cols.append(cnt)
                        elements_iter.remove(elem)
                        break

    # Update min vals and string in elem vals
        example1 = "<"
        example2 = "< "
        example3 = ">"
        example4 = "> "
        for col in range(len(vals)):
            if not col in elem_cols:
                continue
            for row in range(len(vals[col])):
                if vals[col][row].find(example2) != -1:
                    a = vals[col][row].replace(example2, "")
                    try:
                        a = str(float(a)/2)
                    except:
                        a = '' 
                    vals[col][row] = a
                elif vals[col][row].find(example1) != -1:
                    a = vals[col][row].replace(example1, "")
                    try:
                        a = str(float(a)/2)
                    except:
                        a = '' 
                    vals[col][row] = a
                elif vals[col][row].find(example4) != -1:
                    a = vals[col][row].replace(example4, "") 
                    vals[col][row] = a
                elif vals[col][row].find(example3) != -1:
                    a = vals[col][row].replace(example3, "") 
                    vals[col][row] = a
                try:
                    test = float(vals[col][row])
                except ValueError:
                    vals[col][row] = ""
           
        dict_main = dict(zip(keys, vals))

        # Update Table
        cols = len(dict_main.keys())
        rows = len(dict_main[keys[0]])
        self.dlg_drifting.tableWidget.setRowCount(rows+1)
        self.dlg_drifting.tableWidget.setColumnCount(cols)
        self.dlg_drifting.tableWidget.setHorizontalHeaderLabels(keys)
        self.dlg_drifting.lcdRows.display(rows)
        self.dlg_drifting.lcdCols.display(len(elements))

        ff = f / 2
        self.head_table = []
        for j in range(cols):
            self.head_table.append(self.dlg_drifting.tableWidget.horizontalHeaderItem(j).text())
            for i in range(rows):
                ff -= 1
                if ff % 200 == 0:
                    self.dlg_drifting.progressBar.setValue(((f - ff)/f)*100)
                    QApplication.processEvents()
                item = dict_main[keys[j]][i]
                self.dlg_drifting.tableWidget.setItem(i+1, j, QTableWidgetItem(item))
        self.dlg_drifting.progressBar.setValue(0)

        # Update Chek Box
        for i in range(self.dlg_drifting.CB_Element.count()):
            self.dlg_drifting.CB_Element.removeItem(0)
        for elem in elements:
            self.dlg_drifting.CB_Element.addItem(elem)

        # Export correct data to file
        export_arr = []
        strr = ''
        for head in keys:
            export_arr.append(dict_main[head])
            strr += head + '\t'
        strr = strr[:-1]
        strr += '\n'
        transpose = list(map(list, zip(*export_arr)))
        with open(directory + '/' + 'correct_data.txt', 'w', encoding = 'Windows-1251') as f:
            f.write(strr)
        with open(directory + '/' + 'correct_data.txt', "a+") as f:
            np.savetxt(f, transpose, delimiter = '\t', fmt='%s')

    def Sort(self):
        self.items = QComboBox()
        try:
            self.items.addItems(self.head_table)
        except:
            mbox.setText('Пустая таблица')
            mbox.show()
            return
        label = QtWidgets.QLabel()
        label.setText('Столбец для сортировки')
        self.dlg = QDialog()
        layout = QVBoxLayout()
        self.dlg.setWindowTitle("Sort")
        self.dlg.resize(180, 100)
        layout.addWidget(label)
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        layout.addWidget(self.items)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok)
        btnBox.accepted.connect(self.SortOK)
        btnBox.rejected.connect(self.rejectDlg)
        layout.addWidget(btnBox)
        self.chBox = QCheckBox('Descending')
        layout.addWidget(self.chBox)
        self.dlg.setLayout(layout)
        self.dlg.exec_()

    def SortOK(self):
        rev = False
        if self.chBox.isChecked() == True:
            rev = True
        self.dlg.close()
        check = self.items.currentText()
        check_index = self.items.currentIndex()

        arr_for_sort = []
        cols = self.dlg_drifting.tableWidget.columnCount()
        rows = self.dlg_drifting.tableWidget.rowCount()

        for i in range(1, rows):
            ar = []
            for j in range(cols):
                if j == check_index:
                    if self.dlg_drifting.tableWidget.item(i, j).text().find('.') != -1:
                        try:
                            ar.append(float(self.dlg_drifting.tableWidget.item(i, j).text()))
                        except ValueError:
                            mbox.setText('Есть не числовые значения')
                            mbox.show()
                            return
                    elif self.dlg_drifting.tableWidget.item(i, j).text().isnumeric() == False:
                        ar.append(self.dlg_drifting.tableWidget.item(i, j).text())
                    else:
                        ar.append(int(self.dlg_drifting.tableWidget.item(i, j).text()))
                else:
                    ar.append(self.dlg_drifting.tableWidget.item(i, j).text())
            arr_for_sort.append(ar)

        #arr_for_sort = sorted(arr_for_sort, key=itemgetter(check_index))
        arr_for_sort.sort(key=lambda x: (x[check_index]), reverse=rev)

        # Update Table
        f = rows * cols
        ff = f
        for i in range(1, rows):
            for j in range(cols):
                ff -= 1
                if ff % 200 == 0:
                    self.dlg_drifting.progressBar.setValue(((f - ff)/f)*100)
                    QApplication.processEvents()
                self.dlg_drifting.tableWidget.setItem(i, j, QTableWidgetItem(str(arr_for_sort[i-1][j])))
        self.dlg_drifting.progressBar.setValue(0)

    #--------------------------------------------------------------------------
    # Statistics
    #--------------------------------------------------------------------------    
    def Statistics(self):
        keys = self.data_stat[0]
        Element = self.dlg_statistics.CB_Element_stat.currentText()
        div_num = int(self.dlg_statistics.Div_num.text()) 

        # fill arr
        arr = []
        cnt = -1
        for head in keys:
            cnt += 1 
            if head.find(Element) != -1:
                if len(head) > 2 and len(head) < 7:
                    if head.find(Element + ' ') != -1 or head.find(Element + '_') != -1:
                        for _ in range(1, len(self.data_stat)):
                            try:
                                arr.append(float(self.data_stat[_][cnt]))
                            except ValueError:
                                continue
                        break
                elif len(head) == 2 and len(Element) == 1:
                    continue
                elif len(head) == 2 and len(Element) == 2:
                    for _ in range(1, len(self.data_stat)):
                        try:
                            arr.append(float(self.data_stat[_][cnt]))
                        except ValueError:
                            continue
                    break
                elif len(head) == 1 and len(Element) == 1:
                    for _ in range(1, len(self.data_stat)):
                        try:
                            arr.append(float(self.data_stat[_][cnt]))
                        except ValueError:
                            continue
                    break
        if not arr:
            mbox.setText('Элемент не найден')
            mbox.show()
            return

        # def intervals           
        max_arr = max(arr)
        min_arr = min(arr)
        mean = round(np.mean(arr), 4)
        median = round(np.median(arr), 4)
        std = round(statistics.stdev(arr), 4)
        sort_arr = sorted(arr)

        ticks = []
        div_arr = max_arr - min_arr
        div_step = round((div_arr/10), 2)
        divsum = min_arr
        for i in range(12):
            divsum = round((divsum + div_step), 2)
            if divsum > max_arr:
                break
            ticks.append(divsum)

        interval = round(((max_arr-min_arr) / div_num), 8)
        n = [min_arr]
        for _ in range(div_num):
            n.append(round((n[_]+interval+0.00_000_1), 6))

        # def freq
        freq = 0
        val = []
        n_central = []
        for _ in range(len(n)):
            for i in range(len(arr)):
                if _ == len(n) -1:
                    val[-1] = val[-1] + 1
                    break
                if n[_] <= arr[i] < n[_+1]:
                    freq += 1
            val.append(freq)
            if _ == len(n) -1:
                break
            n_central.append(round(((n[_]+n[_+1])/2), 5))
            freq = 0
        del val[-1]

        Q1 = sort_arr[int(len(arr) * 1/4)]
        Q3 = sort_arr[int(len(arr) * 3/4)]
        #random.shuffle(val)

        # Draw hyst
        self.layout = QtWidgets.QVBoxLayout()
        
        self.dlg_statistics.widget.setLayout(self.layout)
        self.canvas = FigureCanvas(plt.Figure())
        self.canvas.figure.subplots_adjust(left=0.05,right=0.98,
                            bottom=0.1,top=0.95,
                            hspace=0,wspace=0)
        toolbar = NavigationToolbar(self.canvas, self.dlg_statistics)
        self.canvases.append((self.canvas, toolbar))
        
        self.layout.addWidget(toolbar)
        self.layout.addWidget(self.canvas)
        self.layout.deleteLater()

        self.ax = self.canvas.figure.subplots()
        self.ax.set_title(Element)
        self.ax.set_xlabel("Значение")
        self.ax.set_ylabel("Частота")
        self.ax.annotate("$Min = $"+str(min_arr), xy=(0.87, 0.97), xycoords='axes fraction', fontsize=11)
        self.ax.annotate("$Max = $"+str(max_arr), xy=(0.87, 0.94), xycoords='axes fraction', fontsize=11)
        self.ax.annotate("$Mean = $"+str(mean), xy=(0.87, 0.91), xycoords='axes fraction', fontsize=11)
        self.ax.annotate("$Med = $"+str(median), xy=(0.87, 0.88), xycoords='axes fraction', fontsize=11)
        self.ax.annotate("$Std = $"+str(std), xy=(0.87, 0.85), xycoords='axes fraction', fontsize=11)
        self.bar = None
        
        if self.bar:
            self.bar.remove()
        self.bar = self.ax.bar(n_central, val, width=interval/1.2)
        self.ax.plot([Q1, Q1], [0, max(val)*0.8], "k--", color='b')
        self.ax.plot([Q3, Q3], [0, max(val)*0.8], "k--", color='b')
        self.ax.set_xlim(left=min(arr), right=max(arr))
        self.ax.set_xticks(ticks)
        #print(dir(self.ax))

        n = int(self.dlg_statistics.Step_curve.text())  
        step = int(n/2)
        cumsum = np.cumsum(np.insert(val, 0, 0)) 
        np_val = (cumsum[n:] - cumsum[:-n]) / n
        a = np_val.tolist()
        for i in range(step):
            a.insert(i, val[i])
            a.insert(len(a)-i, val[-(i+1)])

        self.ax.plot(n_central, a, color ='r')

        val_norm = []
        for i in range(len(arr)):
            val_norm.append(round((arr[i]-min(arr)) / (max(arr)-min(arr)), 8))

        ax1 = self.bar[0].axes
        lim = ax1.get_xlim() + ax1.get_ylim()
        bot = 0.7
        cnt = -1
        for band in self.bar:
            cnt += 1
            band.set_zorder(1)
            band.set_facecolor("none")
            x, y = band.get_xy()
            w, h = band.get_width(), band.get_height()
            hh = (h + ((max(val)*bot) * ((max(val)-h)/max(val)))) / max(val)
            grad = np.atleast_2d(np.linspace(hh, bot, 50)).T
            ax1.imshow(grad, extent=[x,x+w,0,h], cmap='RdYlBu', 
                aspect="auto", zorder=0, norm=mpl.colors.NoNorm(vmin=0,vmax=1))
        ax1.axis(lim)

    def Scatter_Plot(self):
        keys = self.data_stat[0]
        Element_1 = self.dlg_statistics.Elem_CB1.currentText()
        Element_2 = self.dlg_statistics.Elem_CB2.currentText()
        elem_col =[]
        elements = []
        elements.append(Element_1)
        elements.append(Element_2)
        compare = []

        # def col elems
        for Element in elements:
            cnt = -1
            for head in keys:
                cnt += 1 
                if head.find(Element) != -1:
                    if len(head) > 2 and len(head) < 7:
                        if head.find(Element + ' ') != -1 or head.find(Element + '_') != -1:
                            elem_col.append(cnt)
                            break
                    elif len(head) == 2 and len(Element) == 1:
                        continue
                    elif len(head) == 2 and len(Element) == 2:
                        elem_col.append(cnt)
                        break
                    elif len(head) == 1 and len(Element) == 1:
                        elem_col.append(cnt)
                        break
            if not elem_col:
                mbox.setText('Элемент не найден')
                mbox.show()
                return

        arr_1 = []
        arr_2 = []
        for _ in range(1, len(self.data_stat)):
            try:
                val_1 = float(self.data_stat[_][elem_col[0]])
                val_2 = float(self.data_stat[_][elem_col[1]])
            except ValueError:
                continue
            arr_1.append(val_1)
            arr_2.append(val_2)

        val_norm = []
        for i in range(len(arr_1)):
            val_norm.append(round((arr_1[i]-min(arr_1)) / (max(arr_1)-min(arr_1)), 8))
        compare.append(val_norm)
        val_norm = []
        for i in range(len(arr_1)):
            val_norm.append(round((arr_2[i]-min(arr_2)) / (max(arr_2)-min(arr_2)), 8))
        compare.append(val_norm)

        # Draw Scatter
        self.layout = QtWidgets.QVBoxLayout()
        
        self.dlg_statistics.widget.setLayout(self.layout)
        self.canvas = FigureCanvas(plt.Figure())
        self.canvas.figure.subplots_adjust(left=0.05,right=0.98,
                            bottom=0.1,top=0.95,
                            hspace=0,wspace=0)
        toolbar = NavigationToolbar(self.canvas, self.dlg_statistics)
        self.canvases.append((self.canvas, toolbar))
        
        self.layout.addWidget(toolbar)
        self.layout.addWidget(self.canvas)
        self.layout.deleteLater()

        self.ax = self.canvas.figure.subplots()
        self.ax.set_title(Element_1 + ' + ' + Element_2)
        self.ax.set_xlabel(Element_1)
        self.ax.set_ylabel(Element_2)
        
        self.scatter = None
        
        if self.scatter:
            self.scatter.remove()
        self.scatter = self.ax.scatter(compare[0], compare[1], s=8)

        z = np.polyfit(compare[0], compare[1], 1)
        p = np.poly1d(z)
        self.ax.plot(compare[0], p(compare[0]), "r--")
        self.ax.grid(linestyle='--')
        self.ax.grid(linewidth=1)


    def del_stat(self):
        for canvas in self.canvases:
            canvas[0].deleteLater()
            canvas[1].deleteLater()
        self.canvases = []

    def load_stat(self):
        file_path = self.dlg_statistics.FW_stat.filePath()
        try:
            with open(file_path, 'r', encoding = 'Windows-1251') as file:
                lines = file.readlines()
        except FileNotFoundError:
            mbox.setText('Нужно выбрать 1 файл')
            mbox.show()
            return
        data = []
        for i in range(len(lines)):
            line = lines[i].replace('\n','').split('\t')
            data.append(line)
        self.data_stat = data.copy()

        # Define elements in file
        elements_iter = element_names.copy()
        col_cnt = len(data[0])
        for i in range(self.dlg_statistics.CB_Element_stat.count()):
            self.dlg_statistics.CB_Element_stat.removeItem(0)
            self.dlg_statistics.Elem_CB1.removeItem(0)
            self.dlg_statistics.Elem_CB2.removeItem(0)
        for i in range(col_cnt):
            for j in range(len(elements_iter)):
                if data[0][i].find(elements_iter[j]) != -1:
                    if len(data[0][i]) > 2:
                        if data[0][i].find(elements_iter[j] + ' ') != -1 or data[0][i].find(elements_iter[j] + '_') != -1:
                            self.dlg_statistics.CB_Element_stat.addItem(elements_iter[j])
                            self.dlg_statistics.Elem_CB1.addItem(elements_iter[j])
                            self.dlg_statistics.Elem_CB2.addItem(elements_iter[j])
                            del elements_iter[j]
                            break
                    elif len(data[0][i]) == 2 and len(elements_iter[j]) == 1:
                        continue
                    elif len(data[0][i]) == 2 and len(elements_iter[j]) == 2:
                        self.dlg_statistics.CB_Element_stat.addItem(elements_iter[j])
                        self.dlg_statistics.Elem_CB1.addItem(elements_iter[j])
                        self.dlg_statistics.Elem_CB2.addItem(elements_iter[j])
                        del elements_iter[j]
                        break
                    else:
                        self.dlg_statistics.CB_Element_stat.addItem(elements_iter[j])
                        self.dlg_statistics.Elem_CB1.addItem(elements_iter[j])
                        self.dlg_statistics.Elem_CB2.addItem(elements_iter[j])
                        del elements_iter[j]
                        break

    #--------------------------------------------------------------------------
    # Layouts
    #--------------------------------------------------------------------------    
    def Layout(self):
        layers = []
        layers_2 = []
        layers_3 = []

        for i in range(self.dlg_layout.listWidget.count()):
            layerText = self.dlg_layout.listWidget.item(i).text()
            L1 = layerText
            for char in layerText:
                if char != '|':
                    L1 = L1[1:]
                else:
                    L1 = L1[2:]
                    break
            layer = QgsProject.instance().layerTreeRoot().findLayer(L1).layer()
            layers.append(layer)

        for i in range(self.dlg_layout.listWidget_2.count()):
            layerText = self.dlg_layout.listWidget_2.item(i).text()
            L1 = layerText
            for char in layerText:
                if char != '|':
                    L1 = L1[1:]
                else:
                    L1 = L1[2:]
                    break
            layer = QgsProject.instance().layerTreeRoot().findLayer(L1).layer()
            layers_2.append(layer)

        for i in range(self.dlg_layout.listWidget_3.count()):
            layerText = self.dlg_layout.listWidget_3.item(i).text()
            L1 = layerText
            for char in layerText:
                if char != '|':
                    L1 = L1[1:]
                else:
                    L1 = L1[2:]
                    break
            layer = QgsProject.instance().layerTreeRoot().findLayer(L1).layer()
            layers_3.append(layer)

        lrs = []
        elements = []
        type_layout = self.dlg_layout.lineEdit.text()
        area_name = self.dlg_layout.lineEdit_7.text()

        # Define selected elements
        elements_iter = element_names.copy()

        for layer in layers:
            for j in range(len(elements_iter)):
                if layer.name().find(elements_iter[j]) != -1:
                    if len(layer.name()) > 2:
                        if (layer.name().find(elements_iter[j] + ' ') != -1 or layer.name().find(elements_iter[j] + '_') != -1
                        or layer.name().find(' ' + elements_iter[j]) != -1 or layer.name().find('_' + elements_iter[j]) != -1):
                            elements.append(elements_iter[j])
                            del elements_iter[j]
                            break
                    else:
                        elements.append(elements_iter[j])
                        del elements_iter[j]
                        break

        project = QgsProject.instance()
        manager = project.layoutManager()
        layout = manager.layoutByName(self.dlg_layout.LayoutName.text())

        legend = layout.itemById("Legend")
        legend1 = layout.itemById("Legend1")
        
        map1 = layout.itemById("Map")

        # Remove layer from layout legend
        for i in range(len(layers)):
            lrs.append(layers[i].name())
            model = legend.model()
            root = model.rootGroup().findLayer(layers[i])
            if root != None:
                if root.name() == layers[i].name():
                    model.rootGroup().removeLayer(layers[i])

        # Add and change layer in layout legend
        cnt = 0
        l1 = self.dlg_layout.lineEdit_1.text()
        l2 = int(self.dlg_layout.lineEdit_2.text())  
        l3 = self.dlg_layout.lineEdit_3.text()
        l4 = int(self.dlg_layout.lineEdit_4.text()) - 1
        l5 = self.dlg_layout.lineEdit_5.text()
        l6 = self.dlg_layout.lineEdit_6.text()
        for i in range(len(elements)):
            # Change Legend
            self.dlg_layout.progressBar.setValue(int((100/len(lrs))*cnt))
            QApplication.processEvents()
            map1.setKeepLayerSet(False)
            map1.setKeepLayerStyles(False)
            cnt += 1
            model = legend.model()
            model.rootGroup().insertChildNode(0, QgsLayerTreeLayer(layers[i]))
            root = model.rootGroup().findLayer(layers[i])
            root.setName(layers[i].name())
            nodes = model.layerLegendNodes(root)

            if nodes[0].data(0).find('Канал 1') != -1:
                indexes = list(range(1, len(nodes)))
                QgsMapLayerLegendUtils.setLegendNodeOrder(root, indexes)
                legend.model().refreshLayerLegend(root)

            legend.refresh()

            if area_name != '':
                path = project.absolutePath() + "/Прил."+str(l2)+".л."+str(l4+cnt)+"."+type_layout+"_"+elements[cnt-1]+"_"+area_name+".jpg"
                pril_name = "Прил."+str(l2)+".л."+str(l4+cnt)+"."+type_layout+"_"+elements[cnt-1]+"_"+area_name
            else:
                path = project.absolutePath() + "/Прил."+str(l2)+".л."+str(l4+cnt)+"."+type_layout+"_"+elements[cnt-1]+".jpg"
                pril_name = "Прил."+str(l2)+".л."+str(l4+cnt)+"."+type_layout+"_"+elements[cnt-1]

            # Change Text
            Text1 = layout.itemById("Text_1")
            Text2 = layout.itemById("Text_2")
            Text1_change = l1 + " " + str(l2) + "\n" + l3 + " " + str(l4+cnt)
            Text2_change = l5 + " " + elements[cnt-1] + " " + l6
            Text1.setText(Text1_change)
            Text2.setText(Text2_change)

            project.layerTreeRoot().findLayer(layers[i]).setItemVisibilityChecked(True)
            if self.dlg_layout.double_layers.isChecked():
                project.layerTreeRoot().findLayer(layers_2[i]).setItemVisibilityChecked(True)
                if legend1:
                    model1 = legend1.model()
                    mr1 = model1.rootGroup()
                    nodes = model1.layerLegendNodes(root)
                    child = mr1.children()[0]
                    child.setCustomProperty("legend/label-0", layers_2[i].name())
                    legend1.updateLegend()
            elif self.dlg_layout.triple_layers.isChecked():
                project.layerTreeRoot().findLayer(layers_2[i]).setItemVisibilityChecked(True)
                project.layerTreeRoot().findLayer(layers_3[i]).setItemVisibilityChecked(True)
                if legend1:
                    model1 = legend1.model()
                    mr1 = model1.rootGroup()
                    nodes = model1.layerLegendNodes(root)
                    child = mr1.children()[0]
                    child.setCustomProperty("legend/label-0", layers_2[i].name())
                    legend1.updateLegend()

            checked_layers = project.layerTreeRoot().checkedLayers()
            map1.setLayers(checked_layers)
            map1.setKeepLayerSet(True)
            map1.setKeepLayerStyles(True)

            layout.refresh()

            layout.saveAsTemplate(project.absolutePath()+"/"+pril_name+".qpt", QgsReadWriteContext())
            project.layerTreeRoot().findLayer(layers[i]).setItemVisibilityChecked(False)
            if self.dlg_layout.double_layers.isChecked():
                project.layerTreeRoot().findLayer(layers_2[i]).setItemVisibilityChecked(False)
            elif self.dlg_layout.triple_layers.isChecked():
                project.layerTreeRoot().findLayer(layers_2[i]).setItemVisibilityChecked(False)
                project.layerTreeRoot().findLayer(layers_3[i]).setItemVisibilityChecked(False)
            root.setName(lrs[cnt-1])
            model.rootGroup().removeLayer(layers[i])
            print(layers[i].name()) 

            lay = QgsPrintLayout(project)
            lay.initializeDefaults()
            manager.addLayout(lay)
            
            # Save layout
            with open(project.absolutePath()+"/"+pril_name+".qpt") as f:
                template_content = f.read()
                doc = QDomDocument()
                doc.setContent(template_content)
                items, ok = lay.loadFromTemplate(doc, QgsReadWriteContext(), True)
                lay.setName(pril_name)
                project.layoutManager().addLayout(lay)

            # Export to image
            layout_new = manager.layoutByName(pril_name)
            exporter = QgsLayoutExporter(layout_new)
            settings = exporter.ImageExportSettings()
            settings.dpi = int(self.dlg_layout.DPI.text())
            exporter.exportToImage(path, settings)

        self.dlg_layout.progressBar.setValue(0)


    def export_layouts(self):
        label = QtWidgets.QLabel()
        label.setText('Выбрать макеты')
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont('MS Shell Dlg 2', 10))
        self.dlg = QDialog()
        self.list = QListWidget()

        layout = QVBoxLayout()
        self.dlg.setWindowTitle("Layouts selection")
        self.dlg.resize(400, 800)
        layout.addWidget(label)


        project = QgsProject.instance()
        layouts = project.layoutManager().layouts()

        for i in layouts:
            self.list.addItem(i.name())

        self.list.setSelectionMode(3)
        layout.addWidget(self.list)
        btnBox = QDialogButtonBox()
        btnBox.setStandardButtons(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)

        btnBox.accepted.connect(self.export_layouts_OK)
        btnBox.rejected.connect(self.rejectDlg)
        layout.addWidget(btnBox)
        self.dlg.setLayout(layout)
        self.dlg.exec_()

    def export_layouts_OK(self):
        self.dlg.close()
        list_layouts = self.list.selectedItems()
        project = QgsProject.instance()
        manager = project.layoutManager()
        for i in range(len(list_layouts)):
            self.dlg_layout.progressBar.setValue((100/len(list_layouts))*(i+1))
            QApplication.processEvents()
            layout_name = list_layouts[i].text()
            layout = manager.layoutByName(layout_name)
            exporter = QgsLayoutExporter(layout)
            settings = exporter.ImageExportSettings()
            settings.dpi = int(self.dlg_layout.DPI.text())
            path = project.absolutePath() + '/' + list_layouts[i].text() + '.jpg'
            exporter.exportToImage(path, settings)
        self.iface.messageBar().pushMessage("Export successed", 
            level=Qgis.Success, duration=5)
        self.dlg_layout.progressBar.setValue(0)


    def LayersList(self):
        layers = self.iface.layerTreeView().selectedLayers()
        Items = [i.name() +' | '+ i.id() for i in layers]
        for s in Items:
            i = QListWidgetItem(s)
            #i.setFlags(i.flags() | Qt.ItemIsUserCheckable)
            #i.setCheckState(Qt.Checked)
            self.dlg_layout.listWidget.addItem(i)

    def LayersList2(self):
        layers = self.iface.layerTreeView().selectedLayers()
        Items = [i.name() +' | '+ i.id() for i in layers]
        for s in Items:
            i = QListWidgetItem(s)
            self.dlg_layout.listWidget_2.addItem(i)

    def LayersList3(self):
        layers = self.iface.layerTreeView().selectedLayers()
        Vitems = [i.name() +' | '+ i.id() for i in layers if i.type() == QgsMapLayerType.VectorLayer]
        for s in Vitems:
            i = QListWidgetItem(s)
            self.dlg_layout.listWidget_3.addItem(i)

    def ClearList(self):
        self.dlg_layout.listWidget.clear()
    def ClearList2(self):
        self.dlg_layout.listWidget_2.clear()
    def ClearList3(self):
        self.dlg_layout.listWidget_3.clear()

    def PointClass(self):
        Method_index = self.dlg_layout.methodBox.currentIndex()
        Methods = [QgsGraduatedSymbolRenderer.Quantile, QgsGraduatedSymbolRenderer.EqualInterval, QgsGraduatedSymbolRenderer.Jenks, QgsGraduatedSymbolRenderer.StdDev]
        classes = int(self.dlg_layout.Class_cnt.text())
        precision = int(self.dlg_layout.precision.text())
        rgb =   [
                [166, 177, 243],
                [194, 216, 214],
                [227, 248, 169],
                [242, 238, 113],
                [248, 203, 82],
                [254, 141, 81],
                [253, 76, 60],
                [255, 0, 15],
                ]
        firstSize = float(self.dlg_layout.Size_1.text())
        lastSize = float(self.dlg_layout.Size_2.text())
        increment = lastSize - firstSize

        path_scale = [self.plugin_dir + "/samples/scale1.svg", self.plugin_dir + "/samples/scale2.svg"]
        path0 = QgsApplication.prefixPath()
        path1 = "/resources/cpt-city-qgis-min/grass/scale1.svg"
        path2 = "/resources/cpt-city-qgis-min/grass/scale2.svg"
        path = [path0 + path1, path0 + path2]
        check_files = os.path.isfile(path[0])
        check_files1 = os.path.isfile(path[1])

        # read and write svg scale in QGIS folder
        if check_files == False or check_files1 == False:
            for i in range(2):
                strr = ''
                try:
                    with open(path_scale[i], 'r', encoding = 'Windows-1251') as file:
                        lines = file.readlines()
                except FileNotFoundError:
                    mbox.setText('Не найден файл шкалы')
                    mbox.show()
                    return
        
                for string in lines:
                    strr += string
                try:
                    with open(path[i], 'w', encoding = 'Windows-1251') as f:
                        f.write(strr) 
                except PermissionError:
                    mbox.setText("Нужно запустить QGIS от имени администратора")
                    mbox.show()
                    return

        # Define selected elements
        elements_iter = element_names.copy()
        elements = []
        layers = self.iface.layerTreeView().selectedLayers()
        

        for layer in layers:
            for j in range(len(elements_iter)):
                if layer.name().find(elements_iter[j]) != -1:
                    if len(layer.name()) > 2:
                        if (layer.name().find(elements_iter[j] + ' ') != -1 or layer.name().find(elements_iter[j] + '_') != -1
                        or layer.name().find(' ' + elements_iter[j]) != -1 or layer.name().find('_' + elements_iter[j]) != -1):
                            elements.append(elements_iter[j])
                            del elements_iter[j]
                            break
                    else:
                        elements.append(elements_iter[j])
                        del elements_iter[j]
                        break
        if len(elements) == 0:
            mbox.setText("Не найдены слои с элементами")
            mbox.show()
            return

        # Redraw layers
        for c, layer in enumerate(layers):
            self.dlg_layout.progressBar.setValue(int((100/len(layers))*c))
            QApplication.processEvents()

            # Rasters
            if layer.type() == QgsMapLayerType.RasterLayer:
                rlayer = layer
                extent = rlayer.extent()
                pr = rlayer.dataProvider()
                stats = rlayer.dataProvider().bandStatistics(1, QgsRasterBandStats.All)
                Min = stats.minimumValue
                Max = stats.maximumValue
                band_range = Max-Min
                class_range = band_range/8

                rows = rlayer.height()
                columns = rlayer.width()
                block = pr.block(1, extent, columns, rows)
                values = []
                for row in range(rows):
                    for column in range(columns):
                        if block.value(row, column) < 1_000_000_000:
                            values.append(block.value(row, column))
                values.sort()

                quant_cnt = len(values) // 8

                quant = []
                quants = []
                for i in range(8):
                    for q in range(quant_cnt):
                        quant.append(values[q+(i*quant_cnt)])
                    quants.append(quant)
                    quant = []

                fcn = QgsColorRampShader(classificationMode=QgsColorRampShader.Quantile)
                fcn.setColorRampType(QgsColorRampShader.Discrete)
                item_list = []
                r, g, b = (166, 180, 242)
                for i in range(8):
                    Min = min(quants[i])
                    Max = max(quants[i])
                    if i == 8-1:
                        Max = stats.maximumValue
                    n = Max
                    count = 1
                    n //= 10
                    while n > 0:
                        n //= 10
                        count += 1
                    if count >= 3:
                        form = '{0:.0f} - {1:.0f}'.format(Min, Max)
                        if i == 8 - 1:
                            form = "> " + '{0:.0f}'.format(max(quants[i-1]))
                        elif i == 0:
                            form = "<= " + '{0:.0f}'.format(Max)
                    elif count == 2:
                        form = '{0:.1f} - {1:.1f}'.format(Min, Max)
                        if i == 8 - 1:
                            form = "> " + '{0:.1f}'.format(max(quants[i-1]))
                        elif i == 0:
                            form = "<= " + '{0:.1f}'.format(Max)
                    elif count == 1:
                        form = '{0:.2f} - {1:.2f}'.format(Min, Max)
                        if i == 8 - 1:
                            form = "> " + '{0:.2f}'.format(max(quants[i-1]))
                        elif i == 0:
                            form = "<= " + '{0:.2f}'.format(Max)
                    elif count == 0:
                        form = '{0:.3f} - {1:.3f}'.format(Min, Max)
                        if i == 8 - 1:
                            form = "> " + '{0:.3f}'.format(max(quants[i-1]))
                        elif i == 0:
                            form = "<= " + '{0:.3f}'.format(Max)

                    list_item = QgsColorRampShader.ColorRampItem(Max, QColor(rgb[i][0], rgb[i][1], rgb[i][2]), lbl=form)
                    item_list.append(list_item)

                fcn.setColorRampItemList(item_list)
                shader = QgsRasterShader()
                shader.setRasterShaderFunction(fcn)
                renderer = QgsSingleBandPseudoColorRenderer(pr, 1, shader)
                rlayer.setRenderer(renderer)
                rlayer.triggerRepaint()
                continue

            # Vectors
            vlayer = layer
            fieldList = []
            [fieldList.append(field.name()) for field in vlayer.fields()]
            
            # Find target field
            for i, field in enumerate(fieldList):
                if field.find(elements[c]) == 0 and len(field) == len(elements[c]):
                    TargetField = field
                elif field.find(elements[c] + '_') == 0 or field.find(elements[c] + ' ') == 0 or field.find(elements[c] + '-') == 0:
                    TargetField = field

            Symbol = QgsSymbol.defaultSymbol(vlayer.geometryType())
            ColorRamp = QgsCptCityColorRamp("grass/scale1","", 1)

            QGSR = QgsGraduatedSymbolRenderer()
            Renderer = QGSR.createRenderer(vlayer, TargetField, classes, 1, Symbol, ColorRamp)

            myFormat = QgsRendererRangeLabelFormat()
            myFormat.setFormat("%1 - %2")
            myFormat.setPrecision(precision)
            myFormat.setTrimTrailingZeroes(False)
            if self.dlg_layout.trim_zeros.isChecked():
                myFormat.setTrimTrailingZeroes(True)
            
            Renderer.setUsingSymbolLevels(True)
            Renderer.updateClasses(vlayer, Methods[Method_index], classes)

            Renderer.setLabelFormat(myFormat)
            Renderer.updateRangeLabels()
            
            # labeling
            label0 = Renderer.legendSymbolItems()[0].label()
            labelLast = Renderer.legendSymbolItems()[classes-1].label()
            while label0.find("-") != -1:
                label0 = label0[1:]
            label0 ="<= " + label0[1:]
            for ch, char in enumerate(labelLast):
                if char == ' ':
                    labelLast = "> " + labelLast[:ch]
                    break
            Renderer.updateRangeLabel(0, label0)
            Renderer.updateRangeLabel(classes-1, labelLast)

            if self.dlg_layout.Descending.isChecked():
                Renderer.sortByValue(order=Qt.DescendingOrder)
            
            
            vlayer.setRenderer(Renderer)


            symbols = vlayer.renderer().symbols(QgsRenderContext())
            if classes - len(symbols) != 0:
                mbox.setText("Поле для классификации должно иметь только числовые значения или не найдено поле таблицы с элементом")
                mbox.show()
                return
            for i in range(classes):
                size = firstSize + (increment * i) / (classes - 1)
                symbols[i].setSize(size)
            
            self.iface.layerTreeView().refreshLayerSymbology(vlayer.id())
            QgsProject.instance().layerTreeRoot().findLayer(vlayer.id()).setExpanded(True)
            QgsProject.instance().layerTreeRoot().findLayer(vlayer.id()).isExpanded()
            vlayer.triggerRepaint()
        self.dlg_layout.progressBar.setValue(0)
        self.iface.mapCanvas().refresh()
        #self.iface.mapCanvas().redrawAllLayers()


    def TransferStyles(self):
        elements, Layers1, Layers2 = [], [], []

        for i in range(self.dlg_layout.listWidget.count()):
            layerText= self.dlg_layout.listWidget.item(i).text()
            L1 = layerText
            for char in layerText:
                if char != '|':
                    L1 = L1[1:]
                else:
                    L1 = L1[2:]
                    break
            layer = QgsProject.instance().layerTreeRoot().findLayer(L1)
            Layers1.append(layer.layer())
            
        for i in range(self.dlg_layout.listWidget_2.count()):
            layerText = self.dlg_layout.listWidget_2.item(i).text()
            L1 = layerText
            for char in layerText:
                if char != '|':
                    L1 = L1[1:]
                else:
                    L1 = L1[2:]
                    break
            layer = QgsProject.instance().layerTreeRoot().findLayer(L1)
            Layers2.append(layer.layer())

        val_all_layers = []
        for vlayer in Layers1:
            renderer = vlayer.renderer().legendSymbolItems()
    
            values = []
            for i in renderer:
                label = i.label()
                num_label = re.findall(r"([\d.]*\d+)", label)
                values.append(float(num_label[0]))
            values = sorted(set(values))
            values.append(1_000_000_000)
            val_all_layers.append(values)

        # Def rlaers colors
        for lay, rlayer in enumerate(Layers2):
            pr = rlayer.dataProvider()
            color_list = []
            for value, color in rlayer.renderer().legendSymbologyItems():
                color_list.append([color.red(), color.green(), color.blue()])
            
            item_list = []
            legend_Items = Layers1[lay].renderer().legendSymbolItems()
            legend_Items.reverse()

            # Fill rlayers
            for i, node in enumerate(legend_Items):
                label = node.label()
                item = QgsColorRampShader.ColorRampItem(val_all_layers[lay][i], QColor(color_list[i][0], color_list[i][1], color_list[i][2]), lbl=label)
                item_list.append(item)
                fcn = QgsColorRampShader(classificationMode=QgsColorRampShader.Quantile)
                fcn.setColorRampType(QgsColorRampShader.Discrete)
                fcn.setColorRampItemList(item_list)
                shader = QgsRasterShader()
                shader.setRasterShaderFunction(fcn)
                renderer = QgsSingleBandPseudoColorRenderer(pr, 1, shader)
                rlayer.setRenderer(renderer)
                rlayer.triggerRepaint()

        mboxi.setText('Готово')
        mboxi.show()
        mboxi.exec()
        return

    def pixels_to_contours(self):
        layers = self.iface.layerTreeView().selectedLayers()

        for i, layer in enumerate(layers):
            self.dlg_layout.progressBar.setValue(int((100/len(layers))*i))
            QApplication.processEvents()

            pr = layer.dataProvider()
            path = pr.dataSourceUri()
            (Directory, File) = os.path.split(path)
            dot_pos = File.find('.')
            file_name = File[:dot_pos]
            if self.dlg_layout.lines.isChecked():
                out = Directory + '/' + file_name + '_iso' + '.gpkg' 
            else:
                out = Directory + '/' + file_name + '_pol' + '.gpkg' 

            values, colors, labels = [], [], []
            for item in layer.legendSymbologyItems():
                label_raster = re.findall(r"([\d.]*\d+)", item[0])
                labels.append(item[0])
                values.append(float(label_raster[0]))
                colors.append(item[1])
            values = sorted(set(values))

            str_val = ', '.join(str(x) for x in values)
            str_val_pol = '-fl '+' '.join(str(x) for x in values)


            # Isolines
            if self.dlg_layout.lines.isChecked():
                parameter = {
                            'INPUT':layer,
                            'BAND':1,
                            'INTERVAL':10,
                            'FIELD_NAME':'ELEV',
                            'CREATE_3D':False,
                            'IGNORE_NODATA':False,
                            'NODATA':None,
                            'OFFSET':0,
                            'EXTRA':str_val_pol,
                            'OUTPUT':out
                            }
    
                result = processing.run('gdal:contour', parameter)['OUTPUT'] 
                layer_iso = QgsVectorLayer(result, layer.name() + '_iso', "ogr")
                QgsProject.instance().addMapLayer(layer_iso)
    
                result = None

            else: # Polygons
                parameter = {
                    'INPUT':layer,
                    'BAND':1,
                    'INTERVAL':10,
                    'CREATE_3D':False,
                    'IGNORE_NODATA':False,
                    'NODATA':None,
                    'OFFSET':0,
                    'EXTRA':str_val_pol,
                    'FIELD_NAME_MIN':'VAL_MIN',
                    'FIELD_NAME_MAX':'VAL_MAX',
                    'OUTPUT':out
                    }
                result = processing.run('gdal:contour_polygon', parameter)['OUTPUT']
                layer_iso = QgsVectorLayer(result, layer.name() + '_pol', "ogr")
                QgsProject.instance().addMapLayer(layer_iso)
                parameter = None
                result = None

                # Redraw layer
                pol_layer = self.iface.activeLayer()
                default_style = QgsStyle().defaultStyle()
                color_ramp = default_style.colorRamp('Spectral') 
                color_ramp.invert()
                
                field_index = pol_layer.fields().lookupField('VAL_MAX')
                unique_values = list(pol_layer.uniqueValues(field_index))
                categories = []
                if self.dlg_layout.descend_pol.isChecked(): 
                    colors.reverse()
                    labels.reverse()
                    rev = True
                else:
                    rev = False
                for i, value in enumerate(sorted(unique_values, reverse=rev)):
                    symbol = QgsSymbol.defaultSymbol(pol_layer.geometryType())
                    symbol.setColor(colors[i])
                    category = QgsRendererCategory(value, symbol, labels[i])
                    categories.append(category)
                renderer = QgsCategorizedSymbolRenderer('VAL_MAX', categories) 
                    
                pol_layer.setRenderer(renderer)
                pol_layer.triggerRepaint()

        self.dlg_layout.progressBar.setValue(0)


    def rename_layers(self):
        layers = self.iface.layerTreeView().selectedLayers()
        elements_iter = element_names.copy()
        for layer in layers:
            for j in range(len(elements_iter)):
                if layer.name().find(elements_iter[j]) != -1:
                    if len(layer.name()) > 2:
                        if (layer.name().find(elements_iter[j] + ' ') != -1 or layer.name().find(elements_iter[j] + '_') != -1
                        or layer.name().find(' ' + elements_iter[j]) != -1 or layer.name().find('_' + elements_iter[j]) != -1):
                            element = elements_iter[j]
                            del elements_iter[j]
                            break
                    else:
                        element = elements_iter[j]
                        del elements_iter[j]
                        break
            left_str = self.dlg_layout.lineEdit_5.text() + ' '
            right_str = ' ' + self.dlg_layout.lineEdit_6.text()
            if self.dlg_layout.lineEdit_5.text() == '':
                left_str = ''
            if self.dlg_layout.lineEdit_6.text() == '':
                right_str = ''
            new_name = left_str + element + right_str
            layer.setName(new_name)

    def dup_layer(self):
        layer = self.iface.activeLayer()
        fieldList, elements = [], []
        [fieldList.append(field.name()) for field in layer.fields()]

        elements_iter = element_names.copy()
        for field in fieldList:
            for j in range(len(elements_iter)):
                if field.find(elements_iter[j]) != -1:
                    if len(field) > 2:
                        if (field.find(elements_iter[j] + ' ') != -1 or field.find(elements_iter[j] + '_') != -1
                        or field.find(' ' + elements_iter[j]) != -1 or field.find('_' + elements_iter[j]) != -1):
                            elements.append(elements_iter[j])
                            del elements_iter[j]
                            break
                    else:
                        elements.append(elements_iter[j])
                        del elements_iter[j]
                        break

        for element in elements:
            self.iface.setActiveLayer(layer)
            layer_clone = self.iface.addVectorLayer(layer.source(), element + '_clone', layer.providerType())


    #--------------------------------------------------------------------------
    def run_drifting(self):
        self.dlg_drifting = driftingDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_drifting.show()
        # Buttons click
        self.dlg_drifting.select_batchs.clicked.connect(self.select_batchs)
        self.dlg_drifting.Run.clicked.connect(self.Drifting)
        self.dlg_drifting.Correct_data.clicked.connect(self.Correct)
        self.dlg_drifting.UpdateTable_btn.clicked.connect(self.Update)
        self.dlg_drifting.Sort.clicked.connect(self.Sort)
        self.dlg_drifting.InstallOpenpyxl.clicked.connect(self.InstallOpenpyxl)
        self.dlg_drifting.MergeFiles.clicked.connect(self.MergeFiles)
        self.dlg_drifting.neighbors.clicked.connect(self.neighbors_change_field)
        # Filters
        self.dlg_drifting.Points_CB.setFilters(QgsMapLayerProxyModel.PointLayer) 
        self.dlg_drifting.Points_neighbor_CB.setFilters(QgsMapLayerProxyModel.PointLayer)

    def run_statistics(self):
        self.canvases = []
        self.dlg_statistics = statisticsDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_statistics.show()
        # Buttons click
        self.dlg_statistics.stat.clicked.connect(self.Statistics)
        self.dlg_statistics.Scatter_Plot.clicked.connect(self.Scatter_Plot)
        self.dlg_statistics.del_stat.clicked.connect(self.del_stat)
        self.dlg_statistics.load_stat.clicked.connect(self.load_stat)

    def run_layout(self):
        self.dlg_layout = layoutDialog(parent = self.iface.mainWindow())
        # show the dialog
        self.dlg_layout.show()
        # Buttons click
        self.dlg_layout.export_layouts.clicked.connect(self.export_layouts)
        self.dlg_layout.LayersList.clicked.connect(self.LayersList)
        self.dlg_layout.LayersList2.clicked.connect(self.LayersList2)
        self.dlg_layout.LayersList3.clicked.connect(self.LayersList3)
        self.dlg_layout.ClearList.clicked.connect(self.ClearList)
        self.dlg_layout.ClearList2.clicked.connect(self.ClearList2)
        self.dlg_layout.ClearList3.clicked.connect(self.ClearList3)
        self.dlg_layout.TransferStyles.clicked.connect(self.TransferStyles)
        self.dlg_layout.PointClass.clicked.connect(self.PointClass)
        self.dlg_layout.Layout.clicked.connect(self.Layout)
        self.dlg_layout.pixels_to_contours.clicked.connect(self.pixels_to_contours)
        self.dlg_layout.rename_layers.clicked.connect(self.rename_layers)
        self.dlg_layout.dup_layer.clicked.connect(self.dup_layer)
        # Filters
